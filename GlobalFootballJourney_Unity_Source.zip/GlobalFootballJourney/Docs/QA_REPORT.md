# QA report

## Automated checks completed for this package

- Parsed all 20 C# source files with a C# grammar: no syntax-error nodes found.
- Parsed `Packages/manifest.json`: valid JSON.
- Counted catalog source entries: 211 unique national association names across AFC 46, CAF 54,
  CONCACAF 35, CONMEBOL 10, OFC 11, and UEFA 55.
- Counted 36 unique fictional club names.
- Checked configured progression lengths: quick match 1, International Cup 8, Champions Cup 13
  (including a play-off slot), and Journey 16.
- Added an Editor pre-build validator for catalog counts, unique IDs, stage counts, Boot scene, and URP assignment.
- Corrected goalkeeper material caching, legal kickoff formation positions, render-pipeline fallback selection,
  knockout detection, and tournament table progression during source review.

## Must still be tested inside Unity

The delivery environment did not contain a Unity Editor or Android/Windows platform modules, so it could not
perform Unity assembly compilation, launch Play Mode, profile a GPU, or create trustworthy APK/EXE binaries.
After the first import, run `Global Football > Validate > Run All Checks`, then complete this matrix:

| Area | Required test |
|---|---|
| Editor | Zero Console compile errors after package resolution and automatic setup |
| Match | Kickoff, passing, shooting, switching, both goal lines, touchlines, clock, extra time, pause, forfeit |
| Inputs | Keyboard, one supported gamepad, and multi-touch on a physical Android device |
| Cups | Three international group matches, table ordering, qualification/elimination, Champions top 8/9–24/25–36 |
| Journey | Loss retry, win unlock, final stage completion, restart persistence |
| Display | 16:9, 20:9 notch phone, 16:10, 1440p and 4K UI readability |
| Performance | 30-minute soak, thermal stability, CPU/GPU/frame-time and memory on target low/mid/high devices |
| Builds | Android ARM64 APK install/launch/suspend/resume; Windows 64-bit clean machine launch |

## Known prototype limitations

- Procedural placeholder characters and stadium rather than production Blender/Mixamo assets.
- No licensed players, faces, badges, kits, commentary, competition branding, anthem, trophies, or real clubs.
- Simplified fouls, restarts, goalkeeping, tactical AI, play-off ties and third-place qualification.
- No open-world hub, online multiplayer, accounts, live data, transfers, career mode, store, or localization pack.
- Runtime tournament session is not resumed after closing the app; Journey unlocks and global stats are saved.

