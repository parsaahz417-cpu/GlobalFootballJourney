# Production guide

## Technical baseline

The project targets Unity 6000.5.8f1, URP 17.5, Input System 1.20, and uGUI 2.5. Unity's current manual
recommends the newer Input System over the legacy Input Manager. The same action layer accepts keyboard,
gamepad, and touch, which avoids maintaining three unrelated controllers.

Unity gameplay scripts use **C#**, not C++. Native C/C++ plug-ins are possible for specialised integrations,
but are unnecessary for this prototype.

## Cross-platform graphics strategy

One project can target Android, Windows, and Linux, but one binary cannot run on all three. Each platform gets
its own build from the same source and gameplay code.

- Mobile: Forward rendering, one directional shadow light, 35 m shadow distance, no MSAA by default, 60 FPS.
- Balanced: 70 m shadows, 2x MSAA, 60 FPS.
- Ultra: 110 m shadows, 4x MSAA, target up to 120 FPS.
- Production additions: static batching/instancing, baked stadium lighting, LOD groups, texture streaming,
  occlusion culling, GPU profiling per chipset, and device-specific render scale.

URP performance documentation specifically highlights camera count, shadow distance/cascades, additional-light
shadows, MSAA, and SRP Batcher compatibility as major levers. Those should be tested on a low-end Android phone,
a mid-range phone, an integrated-GPU laptop, and a discrete-GPU desktop before increasing texture resolution.
Increasing output resolution alone does not create better graphics; art quality, lighting, animation, material
response, LODs, temporal stability, and frame pacing matter more.

## Tournament model

The prototype contains all 211 FIFA member-association names as selectable national sides. Its International
Cup uses a compact player-facing campaign: three league/group matches and five knockout steps. The real 2026
competition uses 48 teams in 12 groups of four; a full simulator should generate all fixtures, third-place
ranking, tie-breakers, and the complete bracket behind the playable user's match.

The original Champions Cup contains 36 fictional clubs. Its campaign reflects the current shape of the
European format: eight league matches, a simulated common table, top-eight direct qualification, positions
9–24 entering a play-off, then knockout stages. The prototype intentionally simplifies draw constraints and
two-legged aggregate ties; a production system should implement those rules and official tie-break ordering.

## Character, animation, map, and texture pipeline

### Blender

- Model players at real scale, facing Unity's expected forward axis after export.
- Build a reusable topology with body-shape blendshapes; keep licensed faces out of the base project.
- Create three LODs, a humanoid skeleton, correct weight painting, and simplified shadow meshes.
- Use modular stands and repeated crowd cards for the stadium. Avoid a single huge mesh.
- Apply transforms, triangulate consistently, pack UVs, and export only required objects/actions to FBX.

### Mixamo

Mixamo is useful for auto-rigging an original humanoid and seeding idle/running/celebration animation. Its FAQ
allows characters and animations in personal, commercial, and non-profit projects. Download animation FBX files
with a consistent skeleton, import them as Humanoid in Unity, create avatar masks, and retarget. Football-specific
ball touches and goalkeeper saves still need custom keyframes or motion capture; generic Mixamo clips alone will
look disconnected from the ball.

### Krita

Krita is free/open-source and its licence permits commercial work. Use it for original kit colourways, UI art,
decals, roughness masks, sponsor-free signage, and hand-painted corrections. Keep layered source files outside the
runtime build; export optimised PNG/TGA textures.

### Quixel Mixer and Fab

Mixer can texture an original FBX/OBJ and export PBR maps. The Fab Standard License permits commercial projects
and compatible tools beyond Unreal Engine, but an asset may not be redistributed standalone. Track the source,
licence, acquisition date, and allowed tier for every asset. Do not assume older “Unreal Unlimited” Megascans
downloads automatically have the newer cross-engine licence; reacquire appropriate assets from Fab when needed.

## AI upgrade path

The prototype uses formation anchors, nearest-player pressing, target following, simple pass selection, and
rating-scaled reaction delay. A production football AI should add:

- a possession state machine and tactical phases;
- off-ball space scoring and passing-lane interception tests;
- team compactness, defensive line, width, tempo, and fatigue;
- prediction of ball trajectories and arrival times;
- goalkeeper positioning, catches, parries, diving, and distribution;
- animation-aware actions and foot selection;
- deterministic match simulation for tournament fixtures;
- difficulty that changes decisions and tactics, not unfair physics.

## QA gates

1. Run editor compilation with zero errors and validate 211/36 team counts.
2. Play ten matches using keyboard, gamepad, and a physical Android touch screen.
3. Test every goal line, touchline, pause/resume, forfeit, extra-time, and save transition.
4. Build Android IL2CPP ARM64, Windows 64-bit, and Linux 64-bit.
5. Profile CPU/GPU/memory on physical targets; Editor frame rate is not representative.
6. Add automated EditMode tests for tables and PlayMode tests for kickoff, goal, and full-time transitions.
7. Verify licences, trademarks, store disclosures, privacy requirements, and signing before publication.

## Useful official references

- Unity 6.5 manual: https://docs.unity3d.com/6000.5/Documentation/Manual/UnityManual.html
- Unity Input: https://docs.unity3d.com/6000.5/Documentation/Manual/Input.html
- Input System 1.20: https://docs.unity3d.com/Packages/com.unity.inputsystem@1.20/
- Android APK build: https://docs.unity3d.com/6000.5/Documentation/Manual/android-BuildProcess.html
- Android dependencies: https://docs.unity3d.com/6000.5/Documentation/Manual/android-install-dependencies.html
- Windows builds: https://docs.unity3d.com/6000.5/Documentation/Manual/WindowsStandaloneBinaries.html
- Linux builds: https://docs.unity3d.com/6000.5/Documentation/Manual/build-for-linux.html
- URP performance: https://docs.unity3d.com/6000.0/Documentation/Manual/urp/configure-for-better-performance.html
- FIFA associations: https://inside.fifa.com/associations
- 2026 format: https://www.fifa.com/en/tournaments/mens/worldcup/canadamexicousa2026/articles/groups-how-teams-qualify-tie-breakers
- European format: https://www.uefa.com/uefachampionsleague/news/0268-12157d69ce2d-9f011c70f6fa-1000--new-format-for-champions-league-post-2024-everything-you-ne/
- Blender licence: https://www.blender.org/about/license/
- Mixamo FAQ: https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html
- Krita licence: https://krita.org/en/about/license/
- Fab Standard License: https://www.fab.com/eula
- Mixer installation: https://docs.quixel.com/mixer/1/en/topic/installing-mixer.html
