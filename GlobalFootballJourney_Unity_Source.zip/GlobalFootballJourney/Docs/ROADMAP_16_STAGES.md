# Sixteen-stage production roadmap

This converts the requested sixteen items into milestones with evidence-based completion gates. Repeating
“improve it” is replaced by profiling, playtests, comparisons, and measurable acceptance criteria.

| Stage | Work | Completion gate |
|---|---|---|
| 1 | Learn Unity editor, C#, URP, Input System, Blender, Krita, Mixamo, Mixer, version control, and build profiles. | A small scene builds to Android, Windows, and Linux; an imported humanoid animates; source is committed. |
| 2 | Build the pitch/stadium map in modular pieces in Blender. Mixamo is not a map tool. | Correct 105 x 68 m scale, colliders, LODs, UVs, occlusion zones, and stable 60 FPS target. |
| 3 | Model and rig an original player in Blender; use Mixamo for compatible base clips. | Humanoid avatar validates, deformations pass test poses, and all assets have recorded licences. |
| 4 | Implement locomotion, animation state machine, keyboard/gamepad/touch inputs. | Identical gameplay actions work on PC and a physical Android device without double input. |
| 5 | Implement NPC decisions, rules, national cup, 36-club competition, tables, fixtures, and saves. | Deterministic tests cover qualification, tie-breaks, knockout progression, save/resume, and all team entries. |
| 6 | Establish lighting, PBR materials, camera language, VFX budget, and art direction. | Signed-off visual target at frame budget on representative devices. |
| 7 | Add dynamic resolution/render scale and quality tiers. | Image quality improves without missed frame-time or memory budgets; UI remains resolution-independent. |
| 8 | Research checkpoint: profile, compare reference footage, test physics, review licences and platform rules. | Written findings produce prioritised tasks; no change is accepted only because it “looks better.” |
| 9 | Alpha bug pass. | Zero blocker/critical bugs; automated core tests pass; 30-minute soak has no crash or runaway memory. |
| 10 | Improve feel: first touch, passes, shots, tackles, switching, camera anticipation, audio feedback. | Blind playtest scores improve against the alpha baseline. |
| 11 | Design checkpoint: remove weak systems and rebalance tactics/difficulty. | Updated design document, telemetry review, and approved beta backlog. |
| 12 | Texture pass with original/Fab-licensed materials in Mixer plus Krita corrections. | Correct PBR channels, mipmaps, compression, texel density, and licence manifest. |
| 13 | Beta compatibility and bug pass across target phones/PCs. | Device matrix passes install, launch, suspend/resume, input, match completion, and save migration. |
| 14 | Polish based on measured player feedback. | Tutorial completion, input error rate, match abandonment, and satisfaction meet defined targets. |
| 15 | Final graphics optimisation and accessibility. | Stable frame pacing, readable UI, graphics presets, colour-safe indicators, and thermal soak pass. |
| 16 | Signed Android APK/AAB and Windows/Linux release builds. | Store-ready package, versioning, keystore backup, privacy/legal review, crash reporting, and release notes. |

## What this repository completes

It implements the technical vertical slice spanning stages 1, 4, and 5; a procedural placeholder for stage 2;
the quality settings foundation for stages 6, 7, and 15; validation/build commands for stages 9, 13, and 16;
and this researched plan for the remaining asset-heavy production work.
