using UnityEngine;

namespace GlobalFootball
{
    public static class StadiumBuilder
    {
        public const float PitchLength = 105f;
        public const float PitchWidth = 68f;
        public const float GoalWidth = 7.32f;
        public const float GoalHeight = 2.44f;

        public static void Build(Transform parent)
        {
            Material grassA = RuntimeArt.Material("Grass A", new Color(0.035f, 0.34f, 0.12f), 0f, 0.18f);
            Material grassB = RuntimeArt.Material("Grass B", new Color(0.045f, 0.4f, 0.145f), 0f, 0.18f);
            Material white = RuntimeArt.Material("Pitch White", new Color(0.93f, 0.98f, 0.95f), 0f, 0.35f);
            Material dark = RuntimeArt.Material("Stadium Dark", new Color(0.025f, 0.045f, 0.08f), 0.5f, 0.35f);
            Material seatA = RuntimeArt.Material("Seats Cyan", new Color(0.01f, 0.34f, 0.58f), 0.15f, 0.3f);
            Material seatB = RuntimeArt.Material("Seats Navy", new Color(0.04f, 0.09f, 0.18f), 0.1f, 0.25f);

            RuntimeArt.Primitive(PrimitiveType.Cube, "Pitch Collision", parent, new Vector3(0f, -0.18f, 0f),
                new Vector3(PitchLength + 8f, 0.35f, PitchWidth + 8f), grassA, true);

            int stripeCount = 14;
            float stripeLength = PitchLength / stripeCount;
            for (int i = 0; i < stripeCount; i++)
            {
                float x = -PitchLength * 0.5f + stripeLength * (i + 0.5f);
                RuntimeArt.Primitive(PrimitiveType.Cube, "Mown Grass", parent, new Vector3(x, 0.005f, 0f),
                    new Vector3(stripeLength + 0.04f, 0.012f, PitchWidth), i % 2 == 0 ? grassA : grassB);
            }

            AddPitchMarkings(parent, white);
            AddGoal(parent, -PitchLength * 0.5f, -1f, white);
            AddGoal(parent, PitchLength * 0.5f, 1f, white);
            AddStands(parent, dark, seatA, seatB);
            AddFloodlights(parent, dark, white);
        }

        private static void AddPitchMarkings(Transform parent, Material white)
        {
            float halfL = PitchLength * 0.5f;
            float halfW = PitchWidth * 0.5f;
            float t = 0.11f;
            float y = 0.04f;
            RuntimeArt.Primitive(PrimitiveType.Cube, "Top Touchline", parent, new Vector3(0f, y, halfW),
                new Vector3(PitchLength, 0.018f, t), white);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Bottom Touchline", parent, new Vector3(0f, y, -halfW),
                new Vector3(PitchLength, 0.018f, t), white);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Left Goal Line", parent, new Vector3(-halfL, y, 0f),
                new Vector3(t, 0.018f, PitchWidth), white);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Right Goal Line", parent, new Vector3(halfL, y, 0f),
                new Vector3(t, 0.018f, PitchWidth), white);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Halfway", parent, new Vector3(0f, y, 0f),
                new Vector3(t, 0.018f, PitchWidth), white);
            RuntimeArt.Ring("Centre Circle", parent, white, 9.15f, y + 0.01f, t);
            RuntimeArt.Primitive(PrimitiveType.Cylinder, "Centre Spot", parent, new Vector3(0f, y + 0.01f, 0f),
                new Vector3(0.18f, 0.012f, 0.18f), white);

            AddBox(parent, white, -halfL, 16.5f, 40.32f, 1f, y, t);
            AddBox(parent, white, halfL, 16.5f, 40.32f, -1f, y, t);
            AddBox(parent, white, -halfL, 5.5f, 18.32f, 1f, y, t);
            AddBox(parent, white, halfL, 5.5f, 18.32f, -1f, y, t);
        }

        private static void AddBox(Transform parent, Material material, float goalX, float depth, float width,
            float direction, float y, float t)
        {
            float insideX = goalX + direction * depth;
            RuntimeArt.Primitive(PrimitiveType.Cube, "Box Edge", parent, new Vector3(insideX, y, 0f),
                new Vector3(t, 0.018f, width), material);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Box Side", parent,
                new Vector3(goalX + direction * depth * 0.5f, y, width * 0.5f),
                new Vector3(depth, 0.018f, t), material);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Box Side", parent,
                new Vector3(goalX + direction * depth * 0.5f, y, -width * 0.5f),
                new Vector3(depth, 0.018f, t), material);
        }

        private static void AddGoal(Transform parent, float x, float backDirection, Material white)
        {
            Transform goal = new GameObject(x < 0 ? "Left Goal" : "Right Goal").transform;
            goal.SetParent(parent, false);
            goal.localPosition = new Vector3(x, 0f, 0f);
            float post = 0.12f;
            RuntimeArt.Primitive(PrimitiveType.Cylinder, "Post", goal,
                new Vector3(0f, GoalHeight * 0.5f, GoalWidth * 0.5f),
                new Vector3(post, GoalHeight * 0.5f, post), white, true);
            RuntimeArt.Primitive(PrimitiveType.Cylinder, "Post", goal,
                new Vector3(0f, GoalHeight * 0.5f, -GoalWidth * 0.5f),
                new Vector3(post, GoalHeight * 0.5f, post), white, true);
            RuntimeArt.Primitive(PrimitiveType.Cylinder, "Crossbar", goal,
                new Vector3(0f, GoalHeight, 0f), new Vector3(post, GoalWidth * 0.5f, post), white, true,
                new Vector3(90f, 0f, 0f));

            Material net = RuntimeArt.Material("Goal Net", new Color(0.75f, 0.9f, 1f, 0.65f), 0f, 0.1f);
            float depth = 2.3f * backDirection;
            for (int i = -4; i <= 4; i++)
            {
                float z = i * GoalWidth / 8f;
                RuntimeArt.Line("Net", goal, net, 0.025f, new Vector3(0f, 0.05f, z),
                    new Vector3(depth, 0.05f, z), new Vector3(depth, GoalHeight, z),
                    new Vector3(0f, GoalHeight, z));
            }
            for (int i = 0; i <= 5; i++)
            {
                float h = i * GoalHeight / 5f;
                RuntimeArt.Line("Net", goal, net, 0.025f, new Vector3(depth, h, -GoalWidth * 0.5f),
                    new Vector3(depth, h, GoalWidth * 0.5f));
            }
        }

        private static void AddStands(Transform parent, Material dark, Material seatA, Material seatB)
        {
            for (int tier = 0; tier < 3; tier++)
            {
                float y = 1.2f + tier * 2.1f;
                float sideZ = PitchWidth * 0.5f + 7f + tier * 3.5f;
                Vector3 sideScale = new Vector3(PitchLength + 28f, 2f, 5f);
                RuntimeArt.Primitive(PrimitiveType.Cube, "North Stand", parent,
                    new Vector3(0f, y, sideZ), sideScale, tier % 2 == 0 ? seatA : seatB);
                RuntimeArt.Primitive(PrimitiveType.Cube, "South Stand", parent,
                    new Vector3(0f, y, -sideZ), sideScale, tier % 2 == 0 ? seatB : seatA);

                float endX = PitchLength * 0.5f + 7f + tier * 3.5f;
                Vector3 endScale = new Vector3(5f, 2f, PitchWidth + 14f);
                RuntimeArt.Primitive(PrimitiveType.Cube, "West Stand", parent,
                    new Vector3(-endX, y, 0f), endScale, tier % 2 == 0 ? seatB : seatA);
                RuntimeArt.Primitive(PrimitiveType.Cube, "East Stand", parent,
                    new Vector3(endX, y, 0f), endScale, tier % 2 == 0 ? seatA : seatB);
            }
            RuntimeArt.Primitive(PrimitiveType.Cube, "Stadium Floor", parent, new Vector3(0f, -1.2f, 0f),
                new Vector3(PitchLength + 55f, 2f, PitchWidth + 55f), dark);
        }

        private static void AddFloodlights(Transform parent, Material dark, Material light)
        {
            float x = PitchLength * 0.5f + 15f;
            float z = PitchWidth * 0.5f + 16f;
            foreach (Vector3 corner in new[]
                     {
                         new Vector3(-x, 0f, -z), new Vector3(-x, 0f, z),
                         new Vector3(x, 0f, -z), new Vector3(x, 0f, z)
                     })
            {
                RuntimeArt.Primitive(PrimitiveType.Cylinder, "Floodlight Mast", parent,
                    corner + Vector3.up * 13f, new Vector3(0.25f, 13f, 0.25f), dark);
                RuntimeArt.Primitive(PrimitiveType.Cube, "Floodlight", parent,
                    corner + Vector3.up * 26f, new Vector3(5f, 2.2f, 0.4f), light);
            }
        }
    }
}
