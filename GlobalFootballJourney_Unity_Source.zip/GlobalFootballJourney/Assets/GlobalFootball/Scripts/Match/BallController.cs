using UnityEngine;

namespace GlobalFootball
{
    [RequireComponent(typeof(Rigidbody), typeof(SphereCollider))]
    public sealed class BallController : MonoBehaviour
    {
        private Rigidbody body;
        private float kickCooldown;

        public Vector3 Velocity => body != null ? body.linearVelocity : Vector3.zero;
        public float Speed => Velocity.magnitude;

        public void Initialize()
        {
            transform.localScale = Vector3.one * 0.7f;
            SphereCollider sphere = GetComponent<SphereCollider>();
            sphere.radius = 0.5f;
            PhysicsMaterial physics = new PhysicsMaterial("Football Physics")
            {
                bounciness = 0.58f,
                dynamicFriction = 0.38f,
                staticFriction = 0.42f,
                bounceCombine = PhysicsMaterialCombine.Average,
                frictionCombine = PhysicsMaterialCombine.Average
            };
            sphere.material = physics;
            body = GetComponent<Rigidbody>();
            body.mass = 0.43f;
            body.linearDamping = 0.22f;
            body.angularDamping = 0.08f;
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            GetComponent<Renderer>().sharedMaterial = RuntimeArt.Material("Match Ball", Color.white, 0.05f, 0.58f);
        }

        private void FixedUpdate()
        {
            kickCooldown = Mathf.Max(0f, kickCooldown - Time.fixedDeltaTime);
            Vector3 horizontal = new Vector3(body.linearVelocity.x, 0f, body.linearVelocity.z);
            if (horizontal.magnitude > 34f)
            {
                horizontal = horizontal.normalized * 34f;
                body.linearVelocity = new Vector3(horizontal.x, body.linearVelocity.y, horizontal.z);
            }
            if (transform.position.y < -4f)
                ResetBall(Vector3.zero);
        }

        public bool Kick(Vector3 direction, float power, float lift)
        {
            if (kickCooldown > 0f || direction.sqrMagnitude < 0.01f)
                return false;
            kickCooldown = 0.16f;
            direction.y = 0f;
            direction.Normalize();
            body.linearVelocity *= 0.38f;
            body.AddForce(direction * power + Vector3.up * lift, ForceMode.Impulse);
            body.AddTorque(new Vector3(direction.z, 0f, -direction.x) * power * 0.28f, ForceMode.Impulse);
            return true;
        }

        public void Dribble(Vector3 direction, float desiredSpeed)
        {
            if (kickCooldown > 0f)
                return;
            direction.y = 0f;
            if (direction.sqrMagnitude < 0.01f)
                return;
            direction.Normalize();
            Vector3 targetVelocity = direction * Mathf.Clamp(desiredSpeed, 2.5f, 8.5f);
            Vector3 current = body.linearVelocity;
            Vector3 horizontal = Vector3.Lerp(new Vector3(current.x, 0f, current.z), targetVelocity, 0.09f);
            body.linearVelocity = new Vector3(horizontal.x, current.y, horizontal.z);
        }

        public void ResetBall(Vector3 position)
        {
            transform.position = position + Vector3.up * 0.42f;
            transform.rotation = Quaternion.identity;
            body.linearVelocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
            kickCooldown = 0.4f;
        }
    }
}
