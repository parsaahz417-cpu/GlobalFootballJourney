using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace GlobalFootball
{
    public static class RuntimeArt
    {
        private static readonly Dictionary<string, Material> Materials = new Dictionary<string, Material>();

        public static Material Material(string key, Color color, float metallic = 0f, float smoothness = 0.28f,
            bool emission = false)
        {
            if (Materials.TryGetValue(key, out Material cached) && cached != null)
                return cached;
            Shader shader = GraphicsSettings.currentRenderPipeline != null
                ? Shader.Find("Universal Render Pipeline/Lit")
                : Shader.Find("Standard");
            shader ??= Shader.Find("Universal Render Pipeline/Lit") ?? Shader.Find("Diffuse");
            Material material = new Material(shader) { name = key };
            if (material.HasProperty("_BaseColor")) material.SetColor("_BaseColor", color);
            if (material.HasProperty("_Color")) material.SetColor("_Color", color);
            if (material.HasProperty("_Metallic")) material.SetFloat("_Metallic", metallic);
            if (material.HasProperty("_Smoothness")) material.SetFloat("_Smoothness", smoothness);
            if (emission)
            {
                material.EnableKeyword("_EMISSION");
                if (material.HasProperty("_EmissionColor")) material.SetColor("_EmissionColor", color * 2.2f);
            }
            Materials[key] = material;
            return material;
        }

        public static GameObject Primitive(PrimitiveType type, string name, Transform parent, Vector3 position,
            Vector3 scale, Material material, bool collider = false, Vector3? euler = null)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = position;
            go.transform.localScale = scale;
            if (euler.HasValue)
                go.transform.localEulerAngles = euler.Value;
            Renderer renderer = go.GetComponent<Renderer>();
            if (renderer != null)
                renderer.sharedMaterial = material;
            Collider primitiveCollider = go.GetComponent<Collider>();
            if (primitiveCollider != null && !collider)
                Object.Destroy(primitiveCollider);
            return go;
        }

        public static LineRenderer Line(string name, Transform parent, Material material, float width,
            params Vector3[] points)
        {
            GameObject go = new GameObject(name, typeof(LineRenderer));
            go.transform.SetParent(parent, false);
            LineRenderer line = go.GetComponent<LineRenderer>();
            line.sharedMaterial = material;
            line.useWorldSpace = false;
            line.loop = false;
            line.startWidth = width;
            line.endWidth = width;
            line.positionCount = points.Length;
            line.SetPositions(points);
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            line.receiveShadows = false;
            return line;
        }

        public static LineRenderer Ring(string name, Transform parent, Material material, float radius,
            float y, float width, int segments = 64)
        {
            GameObject go = new GameObject(name, typeof(LineRenderer));
            go.transform.SetParent(parent, false);
            LineRenderer line = go.GetComponent<LineRenderer>();
            line.sharedMaterial = material;
            line.useWorldSpace = false;
            line.loop = true;
            line.startWidth = width;
            line.endWidth = width;
            line.positionCount = segments;
            for (int i = 0; i < segments; i++)
            {
                float angle = i * Mathf.PI * 2f / segments;
                line.SetPosition(i, new Vector3(Mathf.Cos(angle) * radius, y, Mathf.Sin(angle) * radius));
            }
            line.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            return line;
        }
    }
}
