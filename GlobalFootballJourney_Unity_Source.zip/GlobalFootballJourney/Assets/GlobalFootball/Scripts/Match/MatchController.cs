using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace GlobalFootball
{
    public sealed class MatchController : MonoBehaviour
    {
        private readonly List<Footballer> homePlayers = new List<Footballer>(11);
        private readonly List<Footballer> awayPlayers = new List<Footballer>(11);
        private TeamData homeTeam;
        private TeamData awayTeam;
        private CompetitionType competitionType;
        private string stageLabel;
        private float difficulty;
        private Action<int, int> completion;
        private BallController ball;
        private Footballer controlled;
        private BroadcastCamera broadcastCamera;
        private MatchHUD hud;
        private MatchPhase phase;
        private float phaseTimer;
        private float remainingTime;
        private float regulationDuration = 180f;
        private float extraTimeDuration = 45f;
        private bool extraTime;
        private bool initialized;
        private bool finishing;
        private int homeGoals;
        private int awayGoals;
        private Vector3 previousGravity;
        private VolumeProfile runtimeVolumeProfile;

        public void Initialize(TeamData userTeam, TeamData opponentTeam, CompetitionType type,
            string matchStage, float aiDifficulty, Action<int, int> onComplete)
        {
            if (initialized)
                return;
            initialized = true;
            homeTeam = userTeam;
            awayTeam = opponentTeam;
            competitionType = type;
            stageLabel = matchStage;
            difficulty = aiDifficulty;
            completion = onComplete;
            previousGravity = Physics.gravity;
            Physics.gravity = new Vector3(0f, -18f, 0f);
            BuildMatch();
            remainingTime = regulationDuration;
            phase = MatchPhase.PreKickoff;
            phaseTimer = 1.5f;
            hud.ShowBanner("KICK OFF", new Color(0.05f, 0.84f, 1f));
        }

        private void Update()
        {
            if (!initialized || finishing)
                return;
            if (UnifiedInput.ConsumePause())
            {
                if (phase == MatchPhase.Paused)
                    Resume();
                else if (phase == MatchPhase.Playing)
                    Pause();
            }

            if (phase == MatchPhase.Paused || phase == MatchPhase.FullTime)
                return;

            if (phase == MatchPhase.PreKickoff || phase == MatchPhase.GoalPause)
            {
                phaseTimer -= Time.deltaTime;
                if (phaseTimer <= 0f)
                {
                    ResetKickoff();
                    phase = MatchPhase.Playing;
                    hud.ClearBanner();
                }
                return;
            }

            if (phase != MatchPhase.Playing)
                return;

            if (UnifiedInput.ConsumeSwitch())
                SwitchControlledPlayer();

            float deltaTime = Time.deltaTime;
            for (int i = 0; i < homePlayers.Count; i++)
                homePlayers[i].Tick(deltaTime, homePlayers[i] == controlled);
            for (int i = 0; i < awayPlayers.Count; i++)
                awayPlayers[i].Tick(deltaTime, false);
            ResolvePlayerSpacing();
            DetectGoalOrOut();

            remainingTime -= deltaTime;
            float duration = extraTime ? extraTimeDuration : regulationDuration;
            hud.UpdateClock(1f - Mathf.Clamp01(remainingTime / duration), extraTime);
            if (remainingTime <= 0f)
                HandleClockExpired();
        }

        private void OnDestroy()
        {
            Time.timeScale = 1f;
            Physics.gravity = previousGravity;
            hud?.Dispose();
            if (runtimeVolumeProfile != null)
                Destroy(runtimeVolumeProfile);
        }

        public Vector3 OpponentGoalPosition(int teamIndex)
        {
            float x = teamIndex == 0 ? StadiumBuilder.PitchLength * 0.5f : -StadiumBuilder.PitchLength * 0.5f;
            return new Vector3(x, 0.8f, 0f);
        }

        public bool IsPrimaryChaser(Footballer player)
        {
            List<Footballer> players = player.TeamIndex == 0 ? homePlayers : awayPlayers;
            float bestDistance = float.MaxValue;
            Footballer closest = null;
            Vector3 ballPosition = ball.transform.position;
            for (int i = 0; i < players.Count; i++)
            {
                Footballer candidate = players[i];
                if (candidate.IsGoalkeeper && Mathf.Abs(ballPosition.x - candidate.HomePosition.x) > 17f)
                    continue;
                float distance = (candidate.transform.position - ballPosition).sqrMagnitude;
                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    closest = candidate;
                }
            }
            return closest == player;
        }

        public Footballer FindBestPassTarget(Footballer passer)
        {
            List<Footballer> players = passer.TeamIndex == 0 ? homePlayers : awayPlayers;
            float direction = passer.TeamIndex == 0 ? 1f : -1f;
            Footballer best = null;
            float bestScore = float.MinValue;
            foreach (Footballer candidate in players)
            {
                if (candidate == passer || candidate.IsGoalkeeper)
                    continue;
                Vector3 delta = candidate.transform.position - passer.transform.position;
                float distance = delta.magnitude;
                if (distance < 3.5f || distance > 32f)
                    continue;
                float forward = delta.x * direction;
                float score = forward * 0.8f - Mathf.Abs(delta.z) * 0.18f - distance * 0.12f;
                if (score > bestScore)
                {
                    bestScore = score;
                    best = candidate;
                }
            }
            return best;
        }

        private void BuildMatch()
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.36f, 0.42f, 0.5f);
            RenderSettings.fog = true;
            RenderSettings.fogColor = new Color(0.025f, 0.05f, 0.09f);
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogStartDistance = 105f;
            RenderSettings.fogEndDistance = 230f;

            Transform environment = new GameObject("Procedural Stadium").transform;
            environment.SetParent(transform, false);
            StadiumBuilder.Build(environment);
            BuildLighting();
            BuildPostProcessing();

            GameObject ballObject = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            ballObject.name = "Football";
            ballObject.transform.SetParent(transform, false);
            ball = ballObject.AddComponent<BallController>();
            ball.Initialize();

            Vector3[] formation =
            {
                new Vector3(-48f, 0f, 0f),
                new Vector3(-35f, 0f, -22f), new Vector3(-38f, 0f, -8f),
                new Vector3(-38f, 0f, 8f), new Vector3(-35f, 0f, 22f),
                new Vector3(-17f, 0f, -18f), new Vector3(-20f, 0f, 0f),
                new Vector3(-17f, 0f, 18f), new Vector3(-7f, 0f, -19f),
                new Vector3(-2f, 0f, 0f), new Vector3(-7f, 0f, 19f)
            };
            for (int i = 0; i < formation.Length; i++)
            {
                homePlayers.Add(CreatePlayer(homeTeam, 0, i, formation[i], i == 0, 1f));
                Vector3 mirrored = new Vector3(-formation[i].x, 0f, -formation[i].z);
                awayPlayers.Add(CreatePlayer(awayTeam, 1, i, mirrored, i == 0, difficulty));
            }

            controlled = homePlayers[6];
            controlled.SetControlled(true);

            GameObject cameraObject = new GameObject("Broadcast Camera", typeof(Camera), typeof(AudioListener),
                typeof(BroadcastCamera));
            cameraObject.tag = "MainCamera";
            cameraObject.transform.SetParent(transform, false);
            broadcastCamera = cameraObject.GetComponent<BroadcastCamera>();
            broadcastCamera.Initialize(ball);
            broadcastCamera.SetControlled(controlled);
            hud = new MatchHUD(homeTeam.DisplayName, awayTeam.DisplayName, stageLabel, Pause);
            hud.UpdateScore(homeTeam.DisplayName, awayTeam.DisplayName, homeGoals, awayGoals);
            hud.UpdateClock(0f, false);
        }

        private Footballer CreatePlayer(TeamData team, int side, int index, Vector3 home, bool goalkeeper,
            float aiDifficulty)
        {
            GameObject playerObject = new GameObject($"{team.DisplayName} Player {index + 1}");
            playerObject.transform.SetParent(transform, false);
            Footballer footballer = playerObject.AddComponent<Footballer>();
            footballer.Initialize(this, team, ball, side, index, home, goalkeeper, aiDifficulty);
            return footballer;
        }

        private void BuildLighting()
        {
            GameObject keyObject = new GameObject("Stadium Key Light", typeof(Light));
            keyObject.transform.SetParent(transform, false);
            keyObject.transform.rotation = Quaternion.Euler(48f, -32f, 0f);
            Light key = keyObject.GetComponent<Light>();
            key.type = LightType.Directional;
            key.color = new Color(0.86f, 0.93f, 1f);
            key.intensity = 1.2f;
            key.shadows = LightShadows.Soft;
            key.shadowStrength = 0.72f;

            GameObject fillObject = new GameObject("Warm Fill", typeof(Light));
            fillObject.transform.SetParent(transform, false);
            fillObject.transform.position = new Vector3(-20f, 20f, -22f);
            Light fill = fillObject.GetComponent<Light>();
            fill.type = LightType.Point;
            fill.range = 90f;
            fill.intensity = 1.5f;
            fill.color = new Color(1f, 0.68f, 0.42f);
            fill.shadows = LightShadows.None;
        }

        private void BuildPostProcessing()
        {
            if (GraphicsSettings.currentRenderPipeline == null || SaveSystem.Data.GraphicsPreset == 0)
                return;

            GameObject volumeObject = new GameObject("Broadcast Post Processing", typeof(Volume));
            volumeObject.transform.SetParent(transform, false);
            Volume volume = volumeObject.GetComponent<Volume>();
            volume.isGlobal = true;
            volume.priority = 1f;
            runtimeVolumeProfile = ScriptableObject.CreateInstance<VolumeProfile>();
            runtimeVolumeProfile.name = "Runtime Broadcast Grade";
            volume.sharedProfile = runtimeVolumeProfile;

            ColorAdjustments color = runtimeVolumeProfile.Add<ColorAdjustments>(true);
            color.postExposure.Override(0.08f);
            color.contrast.Override(SaveSystem.Data.GraphicsPreset == 2 ? 11f : 7f);
            color.saturation.Override(5f);

            Bloom bloom = runtimeVolumeProfile.Add<Bloom>(true);
            bloom.intensity.Override(SaveSystem.Data.GraphicsPreset == 2 ? 0.32f : 0.18f);
            bloom.threshold.Override(1.05f);

            Vignette vignette = runtimeVolumeProfile.Add<Vignette>(true);
            vignette.intensity.Override(0.13f);
            vignette.smoothness.Override(0.32f);

            Tonemapping tonemapping = runtimeVolumeProfile.Add<Tonemapping>(true);
            tonemapping.mode.Override(TonemappingMode.ACES);
        }

        private void SwitchControlledPlayer()
        {
            Footballer best = null;
            float bestDistance = float.MaxValue;
            foreach (Footballer player in homePlayers)
            {
                if (player.IsGoalkeeper)
                    continue;
                float distance = (player.transform.position - ball.transform.position).sqrMagnitude;
                if (distance < bestDistance)
                {
                    bestDistance = distance;
                    best = player;
                }
            }
            if (best == null || best == controlled)
                return;
            controlled.SetControlled(false);
            controlled = best;
            controlled.SetControlled(true);
            broadcastCamera.SetControlled(controlled);
        }

        private void ResolvePlayerSpacing()
        {
            for (int team = 0; team < 2; team++)
            {
                List<Footballer> players = team == 0 ? homePlayers : awayPlayers;
                for (int i = 0; i < players.Count; i++)
                {
                    for (int j = i + 1; j < players.Count; j++)
                    {
                        Vector3 delta = players[j].transform.position - players[i].transform.position;
                        delta.y = 0f;
                        float distance = delta.magnitude;
                        if (distance < 0.72f && distance > 0.001f)
                        {
                            Vector3 push = delta.normalized * (0.72f - distance) * 0.5f;
                            players[i].transform.position -= push;
                            players[j].transform.position += push;
                        }
                    }
                }
            }
        }

        private void DetectGoalOrOut()
        {
            Vector3 position = ball.transform.position;
            float halfLength = StadiumBuilder.PitchLength * 0.5f;
            float halfWidth = StadiumBuilder.PitchWidth * 0.5f;
            bool withinGoal = Mathf.Abs(position.z) < StadiumBuilder.GoalWidth * 0.5f &&
                              position.y < StadiumBuilder.GoalHeight + 0.35f;
            if (position.x > halfLength + 0.1f && withinGoal)
            {
                ScoreGoal(0);
                return;
            }
            if (position.x < -halfLength - 0.1f && withinGoal)
            {
                ScoreGoal(1);
                return;
            }
            if (Mathf.Abs(position.z) > halfWidth + 1.4f || Mathf.Abs(position.x) > halfLength + 3.2f)
            {
                Vector3 restart = new Vector3(Mathf.Clamp(position.x, -47f, 47f), 0f,
                    Mathf.Clamp(position.z, -30f, 30f));
                ball.ResetBall(restart);
            }
        }

        private void ScoreGoal(int scoringTeam)
        {
            if (phase != MatchPhase.Playing)
                return;
            if (scoringTeam == 0)
                homeGoals++;
            else
                awayGoals++;
            hud.UpdateScore(homeTeam.DisplayName, awayTeam.DisplayName, homeGoals, awayGoals);
            hud.ShowBanner(scoringTeam == 0 ? "GOAL!" : "OPPONENT GOAL",
                scoringTeam == 0 ? new Color(0.05f, 0.88f, 1f) : new Color(1f, 0.3f, 0.25f));
            phase = MatchPhase.GoalPause;
            phaseTimer = 2f;
        }

        private void ResetKickoff()
        {
            ball.ResetBall(Vector3.zero);
            foreach (Footballer player in homePlayers) player.ResetToHome();
            foreach (Footballer player in awayPlayers) player.ResetToHome();
            SwitchControlledPlayer();
        }

        private void HandleClockExpired()
        {
            bool knockout = ContainsIgnoreCase(stageLabel, "Round") ||
                            ContainsIgnoreCase(stageLabel, "final") ||
                            ContainsIgnoreCase(stageLabel, "Quarter") ||
                            ContainsIgnoreCase(stageLabel, "Semi") ||
                            ContainsIgnoreCase(stageLabel, "Play-off");
            if (!extraTime && knockout && homeGoals == awayGoals)
            {
                extraTime = true;
                remainingTime = extraTimeDuration;
                hud.ShowBanner("EXTRA TIME", new Color(1f, 0.72f, 0.16f));
                phase = MatchPhase.PreKickoff;
                phaseTimer = 1.8f;
                return;
            }
            if (extraTime && homeGoals == awayGoals)
            {
                float homeChance = homeTeam.Rating / (float)(homeTeam.Rating + awayTeam.Rating);
                if (UnityEngine.Random.value <= homeChance)
                    homeGoals++;
                else
                    awayGoals++;
                hud.UpdateScore(homeTeam.DisplayName, awayTeam.DisplayName, homeGoals, awayGoals);
                hud.ShowBanner("PENALTY SHOOTOUT DECIDED", new Color(1f, 0.72f, 0.16f));
            }
            FinishMatch();
        }

        private void Pause()
        {
            if (phase != MatchPhase.Playing)
                return;
            phase = MatchPhase.Paused;
            Time.timeScale = 0f;
            hud.ShowPause(Resume, Forfeit);
        }

        private void Resume()
        {
            if (phase != MatchPhase.Paused)
                return;
            Time.timeScale = 1f;
            phase = MatchPhase.Playing;
            hud.HidePause();
        }

        private void Forfeit()
        {
            Time.timeScale = 1f;
            awayGoals = Mathf.Max(awayGoals, 3);
            homeGoals = Mathf.Min(homeGoals, awayGoals - 1);
            hud.HidePause();
            FinishMatch();
        }

        private void FinishMatch()
        {
            if (finishing)
                return;
            finishing = true;
            phase = MatchPhase.FullTime;
            Time.timeScale = 1f;
            hud.ShowBanner("FULL TIME", Color.white);
            StartCoroutine(FinishRoutine());
        }

        private IEnumerator FinishRoutine()
        {
            yield return new WaitForSecondsRealtime(1.25f);
            completion?.Invoke(homeGoals, awayGoals);
        }

        private static bool ContainsIgnoreCase(string source, string value)
        {
            return source.IndexOf(value, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }
}
