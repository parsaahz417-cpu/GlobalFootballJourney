using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace GlobalFootball
{
    [RequireComponent(typeof(Camera))]
    public sealed class BroadcastCamera : MonoBehaviour
    {
        private BallController ball;
        private Footballer controlled;
        private Vector3 smoothTarget;
        private Vector3 smoothVelocity;
        private Camera cameraComponent;

        public void Initialize(BallController matchBall)
        {
            ball = matchBall;
            cameraComponent = GetComponent<Camera>();
            cameraComponent.fieldOfView = Application.isMobilePlatform ? 49f : 44f;
            cameraComponent.nearClipPlane = 0.2f;
            cameraComponent.farClipPlane = 350f;
            cameraComponent.backgroundColor = new Color(0.012f, 0.022f, 0.045f);
            cameraComponent.clearFlags = CameraClearFlags.SolidColor;
            if (GraphicsSettings.currentRenderPipeline != null)
            {
                UniversalAdditionalCameraData cameraData =
                    cameraComponent.GetComponent<UniversalAdditionalCameraData>();
                if (cameraData == null)
                    cameraData = cameraComponent.gameObject.AddComponent<UniversalAdditionalCameraData>();
                cameraData.renderPostProcessing = SaveSystem.Data.GraphicsPreset > 0;
            }
            transform.position = new Vector3(0f, 31f, -42f);
            smoothTarget = Vector3.zero;
        }

        public void SetControlled(Footballer footballer) => controlled = footballer;

        private void LateUpdate()
        {
            if (ball == null)
                return;
            Vector3 ballPosition = ball.transform.position;
            Vector3 playerPosition = controlled != null ? controlled.transform.position : ballPosition;
            Vector3 desiredTarget = Vector3.Lerp(ballPosition, playerPosition, 0.34f);
            desiredTarget.x = Mathf.Clamp(desiredTarget.x, -42f, 42f);
            desiredTarget.z = Mathf.Clamp(desiredTarget.z, -22f, 22f);
            desiredTarget.y = 0.7f;
            smoothTarget = Vector3.SmoothDamp(smoothTarget, desiredTarget, ref smoothVelocity, 0.24f,
                100f, Time.unscaledDeltaTime);

            float speedZoom = Mathf.Clamp01(ball.Speed / 25f);
            Vector3 desiredPosition = smoothTarget + new Vector3(-2f - speedZoom * 2f,
                29f + speedZoom * 5f, -40f - speedZoom * 6f);
            transform.position = Vector3.Lerp(transform.position, desiredPosition,
                1f - Mathf.Exp(-5f * Time.unscaledDeltaTime));
            Quaternion desiredRotation = Quaternion.LookRotation(smoothTarget - transform.position, Vector3.up);
            transform.rotation = Quaternion.Slerp(transform.rotation, desiredRotation,
                1f - Mathf.Exp(-7f * Time.unscaledDeltaTime));
        }
    }
}
