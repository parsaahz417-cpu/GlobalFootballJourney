using UnityEngine;

namespace GlobalFootball
{
    public sealed class Footballer : MonoBehaviour
    {
        private MatchController match;
        private TeamData team;
        private BallController ball;
        private Transform leftLeg;
        private Transform rightLeg;
        private Transform leftArm;
        private Transform rightArm;
        private GameObject marker;
        private Vector3 homePosition;
        private Vector3 velocity;
        private float decisionTimer;
        private float baseSpeed;
        private float difficulty;
        private bool controlled;
        private bool goalkeeper;

        public int TeamIndex { get; private set; }
        public int PlayerIndex { get; private set; }
        public Vector3 HomePosition => homePosition;
        public Vector3 Velocity => velocity;
        public bool IsGoalkeeper => goalkeeper;

        public void Initialize(MatchController owner, TeamData data, BallController matchBall, int side,
            int playerIndex, Vector3 home, bool isGoalkeeper, float aiDifficulty)
        {
            match = owner;
            team = data;
            ball = matchBall;
            TeamIndex = side;
            PlayerIndex = playerIndex;
            homePosition = home;
            goalkeeper = isGoalkeeper;
            difficulty = aiDifficulty;
            baseSpeed = (goalkeeper ? 6f : 6.6f) + (team.Rating - 60) * 0.035f;
            transform.position = home;
            gameObject.name = $"{data.DisplayName} Player {playerIndex + 1}";
            CapsuleCollider capsule = gameObject.AddComponent<CapsuleCollider>();
            capsule.center = new Vector3(0f, 0.95f, 0f);
            capsule.height = 1.9f;
            capsule.radius = 0.35f;
            Rigidbody rigidbody = gameObject.AddComponent<Rigidbody>();
            rigidbody.isKinematic = true;
            rigidbody.interpolation = RigidbodyInterpolation.Interpolate;
            BuildVisual();
        }

        public void Tick(float deltaTime, bool allowInput)
        {
            if (allowInput && controlled)
                TickHuman(deltaTime);
            else
                TickAI(deltaTime);
            Animate(deltaTime);
        }

        public void SetControlled(bool value)
        {
            controlled = value;
            if (marker != null)
                marker.SetActive(value);
        }

        public void ResetToHome()
        {
            transform.position = homePosition;
            transform.rotation = Quaternion.LookRotation(TeamIndex == 0 ? Vector3.right : Vector3.left);
            velocity = Vector3.zero;
        }

        private void TickHuman(float deltaTime)
        {
            Vector2 input = UnifiedInput.Move;
            Vector3 desired = new Vector3(input.x, 0f, input.y);
            float speed = baseSpeed * (UnifiedInput.SprintHeld ? 1.34f : 1f);
            Move(desired, speed, deltaTime);

            float distance = Vector3.Distance(Flat(transform.position), Flat(ball.transform.position));
            if (distance < 1.55f)
            {
                if (UnifiedInput.ConsumeShoot())
                {
                    Vector3 target = match.OpponentGoalPosition(TeamIndex);
                    Vector3 direction = target - ball.transform.position;
                    ball.Kick(direction, 11.5f + team.Rating * 0.045f, 2.5f);
                }
                else if (UnifiedInput.ConsumePass())
                {
                    Footballer target = match.FindBestPassTarget(this);
                    Vector3 direction = target != null
                        ? target.transform.position - ball.transform.position
                        : transform.forward;
                    ball.Kick(direction, 7.4f, 0.75f);
                }
                else if (desired.sqrMagnitude > 0.05f)
                {
                    ball.Dribble(desired, speed * 0.82f);
                }
            }
        }

        private void TickAI(float deltaTime)
        {
            decisionTimer -= deltaTime;
            Vector3 ballPosition = Flat(ball.transform.position);
            Vector3 target;
            bool chaser = match.IsPrimaryChaser(this);

            if (goalkeeper)
            {
                float ownGoalX = TeamIndex == 0 ? -StadiumBuilder.PitchLength * 0.5f + 2.2f
                    : StadiumBuilder.PitchLength * 0.5f - 2.2f;
                target = new Vector3(ownGoalX, 0f, Mathf.Clamp(ballPosition.z * 0.42f, -3f, 3f));
                if (Mathf.Abs(ballPosition.x - ownGoalX) < 13f)
                    target = ballPosition;
            }
            else if (chaser)
            {
                target = ballPosition;
            }
            else
            {
                float teamDirection = TeamIndex == 0 ? 1f : -1f;
                float ballShift = Mathf.Clamp(ballPosition.x - homePosition.x, -13f, 13f) * 0.42f;
                target = homePosition + new Vector3(ballShift + teamDirection * 1.2f, 0f,
                    Mathf.Clamp(ballPosition.z - homePosition.z, -8f, 8f) * 0.3f);
            }

            Vector3 desired = target - Flat(transform.position);
            float speed = baseSpeed * Mathf.Lerp(0.82f, 1.12f, Mathf.InverseLerp(0.55f, 1.35f, difficulty));
            if (desired.magnitude < 0.45f)
                desired = Vector3.zero;
            Move(desired.normalized, speed, deltaTime);

            float distance = Vector3.Distance(Flat(transform.position), ballPosition);
            if (distance < 1.48f && decisionTimer <= 0f)
            {
                decisionTimer = Mathf.Lerp(0.62f, 0.28f, Mathf.InverseLerp(0.55f, 1.35f, difficulty));
                Vector3 opponentGoal = match.OpponentGoalPosition(TeamIndex);
                float goalDistance = Vector3.Distance(ballPosition, opponentGoal);
                if (goalkeeper || goalDistance < 25f || Random.value < 0.24f * difficulty)
                {
                    Vector3 aim = opponentGoal + Vector3.forward * Random.Range(-2.4f, 2.4f);
                    ball.Kick(aim - ball.transform.position, goalkeeper ? 10f : 10.2f + difficulty * 2.2f,
                        goalkeeper ? 1.4f : 2.2f);
                }
                else
                {
                    Footballer passTarget = match.FindBestPassTarget(this);
                    Vector3 direction = passTarget != null
                        ? passTarget.transform.position - ball.transform.position
                        : opponentGoal - ball.transform.position;
                    ball.Kick(direction, 6.8f + difficulty, 0.65f);
                }
            }
            else if (distance < 1.15f && desired.sqrMagnitude > 0.05f)
            {
                ball.Dribble(desired, speed * 0.75f);
            }
        }

        private void Move(Vector3 direction, float speed, float deltaTime)
        {
            direction.y = 0f;
            if (direction.sqrMagnitude > 1f)
                direction.Normalize();
            Vector3 desiredVelocity = direction * speed;
            velocity = Vector3.Lerp(velocity, desiredVelocity, 1f - Mathf.Exp(-9f * deltaTime));
            Vector3 next = transform.position + velocity * deltaTime;
            next.x = Mathf.Clamp(next.x, -StadiumBuilder.PitchLength * 0.5f + 0.8f,
                StadiumBuilder.PitchLength * 0.5f - 0.8f);
            next.z = Mathf.Clamp(next.z, -StadiumBuilder.PitchWidth * 0.5f + 0.8f,
                StadiumBuilder.PitchWidth * 0.5f - 0.8f);
            next.y = 0f;
            transform.position = next;
            if (velocity.sqrMagnitude > 0.05f)
            {
                Quaternion look = Quaternion.LookRotation(velocity.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, look, 1f - Mathf.Exp(-12f * deltaTime));
            }
        }

        private void Animate(float deltaTime)
        {
            float motion = Mathf.Clamp01(velocity.magnitude / Mathf.Max(0.1f, baseSpeed));
            float phase = Time.time * (7.5f + motion * 4f) + PlayerIndex * 0.43f;
            float swing = Mathf.Sin(phase) * 34f * motion;
            if (leftLeg != null) leftLeg.localRotation = Quaternion.Euler(swing, 0f, 0f);
            if (rightLeg != null) rightLeg.localRotation = Quaternion.Euler(-swing, 0f, 0f);
            if (leftArm != null) leftArm.localRotation = Quaternion.Euler(-swing * 0.65f, 0f, 5f);
            if (rightArm != null) rightArm.localRotation = Quaternion.Euler(swing * 0.65f, 0f, -5f);
        }

        private void BuildVisual()
        {
            string shirtKey = goalkeeper ? $"{team.Id} Goalkeeper" : $"{team.Id} Primary";
            Material shirt = RuntimeArt.Material(shirtKey, goalkeeper
                ? Color.Lerp(team.Secondary, Color.yellow, 0.62f)
                : team.Primary, 0.05f, 0.3f);
            Material shorts = RuntimeArt.Material($"{team.Id} Secondary", team.Secondary, 0.04f, 0.25f);
            Material skin = RuntimeArt.Material("Player Skin", new Color(0.62f, 0.38f, 0.24f), 0f, 0.38f);
            Material boots = RuntimeArt.Material("Player Boots", new Color(0.025f, 0.03f, 0.04f), 0.2f, 0.5f);

            RuntimeArt.Primitive(PrimitiveType.Capsule, "Torso", transform, new Vector3(0f, 1.25f, 0f),
                new Vector3(0.56f, 0.52f, 0.42f), shirt);
            RuntimeArt.Primitive(PrimitiveType.Sphere, "Head", transform, new Vector3(0f, 2.02f, 0f),
                Vector3.one * 0.38f, skin);
            RuntimeArt.Primitive(PrimitiveType.Cube, "Shorts", transform, new Vector3(0f, 0.84f, 0f),
                new Vector3(0.58f, 0.3f, 0.38f), shorts);

            leftLeg = Limb("Left Leg", new Vector3(-0.2f, 0.48f, 0f), shorts, boots, true);
            rightLeg = Limb("Right Leg", new Vector3(0.2f, 0.48f, 0f), shorts, boots, true);
            leftArm = Limb("Left Arm", new Vector3(-0.48f, 1.38f, 0f), shirt, skin, false);
            rightArm = Limb("Right Arm", new Vector3(0.48f, 1.38f, 0f), shirt, skin, false);

            marker = new GameObject("Controlled Marker");
            marker.transform.SetParent(transform, false);
            marker.transform.localPosition = Vector3.zero;
            RuntimeArt.Ring("Selection Ring", marker.transform,
                RuntimeArt.Material("Selection Glow", new Color(0.02f, 0.85f, 1f), 0f, 0.6f, true),
                0.72f, 0.055f, 0.1f, 40);
            marker.SetActive(false);
        }

        private Transform Limb(string name, Vector3 position, Material upper, Material end, bool leg)
        {
            Transform pivot = new GameObject(name).transform;
            pivot.SetParent(transform, false);
            pivot.localPosition = position;
            RuntimeArt.Primitive(PrimitiveType.Cylinder, "Upper", pivot,
                new Vector3(0f, leg ? -0.22f : -0.18f, 0f),
                new Vector3(0.13f, leg ? 0.32f : 0.27f, 0.13f), upper);
            RuntimeArt.Primitive(leg ? PrimitiveType.Cube : PrimitiveType.Sphere, leg ? "Boot" : "Hand", pivot,
                new Vector3(0f, leg ? -0.58f : -0.48f, leg ? 0.1f : 0f),
                leg ? new Vector3(0.24f, 0.16f, 0.42f) : Vector3.one * 0.18f, end);
            return pivot;
        }

        private static Vector3 Flat(Vector3 value) => new Vector3(value.x, 0f, value.z);
    }
}
