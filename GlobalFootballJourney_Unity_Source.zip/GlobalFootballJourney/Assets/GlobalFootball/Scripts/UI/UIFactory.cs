using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace GlobalFootball
{
    public static class UIFactory
    {
        private static Font runtimeFont;

        public static Font RuntimeFont
        {
            get
            {
                if (runtimeFont != null)
                    return runtimeFont;
                runtimeFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
                return runtimeFont;
            }
        }

        public static Canvas CreateCanvas(string name, int sortOrder)
        {
            GameObject go = new GameObject(name, typeof(RectTransform), typeof(Canvas),
                typeof(CanvasScaler), typeof(GraphicRaycaster));
            Canvas canvas = go.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = sortOrder;
            CanvasScaler scaler = go.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;
            return canvas;
        }

        public static RectTransform Panel(Transform parent, string name, Color color,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            GameObject go = new GameObject(name, typeof(RectTransform), typeof(Image));
            go.transform.SetParent(parent, false);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = offsetMin;
            rect.offsetMax = offsetMax;
            go.GetComponent<Image>().color = color;
            return rect;
        }

        public static Text Text(Transform parent, string value, int fontSize, FontStyle style,
            TextAnchor alignment, Color color, Vector2 anchorMin, Vector2 anchorMax,
            Vector2 offsetMin, Vector2 offsetMax)
        {
            GameObject go = new GameObject("Text", typeof(RectTransform), typeof(Text));
            go.transform.SetParent(parent, false);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = offsetMin;
            rect.offsetMax = offsetMax;
            Text text = go.GetComponent<Text>();
            text.text = value;
            text.font = RuntimeFont;
            text.fontSize = fontSize;
            text.fontStyle = style;
            text.alignment = alignment;
            text.color = color;
            text.horizontalOverflow = HorizontalWrapMode.Wrap;
            text.verticalOverflow = VerticalWrapMode.Truncate;
            return text;
        }

        public static Button Button(Transform parent, string label, UnityAction onClick,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax,
            Color? background = null, int fontSize = 28)
        {
            GameObject go = new GameObject(label + " Button", typeof(RectTransform), typeof(Image), typeof(Button));
            go.transform.SetParent(parent, false);
            RectTransform rect = go.GetComponent<RectTransform>();
            rect.anchorMin = anchorMin;
            rect.anchorMax = anchorMax;
            rect.offsetMin = offsetMin;
            rect.offsetMax = offsetMax;
            Image image = go.GetComponent<Image>();
            image.color = background ?? new Color(0.08f, 0.53f, 0.93f, 0.96f);
            Button button = go.GetComponent<Button>();
            if (onClick != null)
                button.onClick.AddListener(onClick);
            ColorBlock colors = button.colors;
            colors.normalColor = Color.white;
            colors.highlightedColor = new Color(0.83f, 0.94f, 1f);
            colors.pressedColor = new Color(0.58f, 0.82f, 1f);
            colors.selectedColor = colors.highlightedColor;
            colors.fadeDuration = 0.08f;
            button.colors = colors;
            Text text = Text(go.transform, label, fontSize, FontStyle.Bold, TextAnchor.MiddleCenter,
                Color.white, Vector2.zero, Vector2.one, new Vector2(12f, 5f), new Vector2(-12f, -5f));
            text.raycastTarget = false;
            return button;
        }

        public static ScrollRect ScrollList(Transform parent, out RectTransform content,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            RectTransform root = Panel(parent, "Scroll View", new Color(0.03f, 0.07f, 0.13f, 0.88f),
                anchorMin, anchorMax, offsetMin, offsetMax);
            ScrollRect scroll = root.gameObject.AddComponent<ScrollRect>();
            RectMask2D mask = root.gameObject.AddComponent<RectMask2D>();
            mask.padding = new Vector4(8f, 8f, 8f, 8f);

            GameObject contentObject = new GameObject("Content", typeof(RectTransform),
                typeof(VerticalLayoutGroup), typeof(ContentSizeFitter));
            contentObject.transform.SetParent(root, false);
            content = contentObject.GetComponent<RectTransform>();
            content.anchorMin = new Vector2(0f, 1f);
            content.anchorMax = new Vector2(1f, 1f);
            content.pivot = new Vector2(0.5f, 1f);
            content.anchoredPosition = Vector2.zero;
            content.sizeDelta = Vector2.zero;
            VerticalLayoutGroup layout = contentObject.GetComponent<VerticalLayoutGroup>();
            layout.padding = new RectOffset(16, 16, 16, 16);
            layout.spacing = 10f;
            layout.childAlignment = TextAnchor.UpperCenter;
            layout.childControlHeight = true;
            layout.childControlWidth = true;
            layout.childForceExpandHeight = false;
            layout.childForceExpandWidth = true;
            ContentSizeFitter fitter = contentObject.GetComponent<ContentSizeFitter>();
            fitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
            scroll.content = content;
            scroll.viewport = root;
            scroll.horizontal = false;
            scroll.vertical = true;
            scroll.movementType = ScrollRect.MovementType.Elastic;
            scroll.scrollSensitivity = 35f;
            return scroll;
        }

        public static LayoutElement Layout(GameObject target, float preferredHeight, float preferredWidth = -1f)
        {
            LayoutElement element = target.AddComponent<LayoutElement>();
            element.preferredHeight = preferredHeight;
            if (preferredWidth > 0f)
                element.preferredWidth = preferredWidth;
            return element;
        }

        public static Slider Slider(Transform parent, float value, UnityAction<float> onChanged,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            RectTransform root = Panel(parent, "Slider", new Color(0.08f, 0.13f, 0.22f, 1f),
                anchorMin, anchorMax, offsetMin, offsetMax);
            Slider slider = root.gameObject.AddComponent<Slider>();
            RectTransform fill = Panel(root, "Fill", new Color(0.05f, 0.75f, 0.95f, 1f),
                Vector2.zero, new Vector2(1f, 1f), new Vector2(4f, 4f), new Vector2(-4f, -4f));
            fill.anchorMax = new Vector2(0f, 1f);
            RectTransform handle = Panel(root, "Handle", Color.white,
                new Vector2(0f, 0.5f), new Vector2(0f, 0.5f), new Vector2(-14f, -14f), new Vector2(14f, 14f));
            slider.fillRect = fill;
            slider.handleRect = handle;
            slider.targetGraphic = handle.GetComponent<Image>();
            slider.minValue = 0f;
            slider.maxValue = 1f;
            slider.value = value;
            slider.onValueChanged.AddListener(onChanged);
            return slider;
        }
    }
}
