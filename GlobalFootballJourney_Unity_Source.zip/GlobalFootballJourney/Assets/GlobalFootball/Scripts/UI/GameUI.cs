using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace GlobalFootball
{
    public sealed class GameUI
    {
        private readonly GameRoot game;
        private readonly Canvas canvas;
        private readonly RectTransform root;
        private readonly Color navy = new Color(0.018f, 0.05f, 0.105f, 0.97f);
        private readonly Color cyan = new Color(0.02f, 0.72f, 0.96f, 1f);

        public GameUI(GameRoot gameRoot)
        {
            game = gameRoot;
            canvas = UIFactory.CreateCanvas("Front End UI", 30);
            UnityEngine.Object.DontDestroyOnLoad(canvas.gameObject);
            root = canvas.GetComponent<RectTransform>();
        }

        public void SetVisible(bool visible) => canvas.gameObject.SetActive(visible);

        public void ShowMainMenu()
        {
            SetVisible(true);
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Panel(root, "Accent", cyan, new Vector2(0f, 0f), new Vector2(0.012f, 1f),
                Vector2.zero, Vector2.zero);
            UIFactory.Text(root, "GLOBAL FOOTBALL\nJOURNEY", 68, FontStyle.Bold, TextAnchor.MiddleLeft,
                Color.white, new Vector2(0.08f, 0.62f), new Vector2(0.62f, 0.93f), Vector2.zero, Vector2.zero);
            UIFactory.Text(root, "A cross-platform 3D football prototype", 28, FontStyle.Normal,
                TextAnchor.MiddleLeft, new Color(0.65f, 0.78f, 0.9f), new Vector2(0.082f, 0.56f),
                new Vector2(0.65f, 0.64f), Vector2.zero, Vector2.zero);

            RectTransform buttons = UIFactory.Panel(root, "Menu", Color.clear, new Vector2(0.08f, 0.08f),
                new Vector2(0.47f, 0.55f), Vector2.zero, Vector2.zero);
            AddMenuButton(buttons, "QUICK MATCH", 0, () => game.RequestTeamSelection(CompetitionType.QuickMatch));
            AddMenuButton(buttons, "INTERNATIONAL CUP", 1,
                () => game.RequestTeamSelection(CompetitionType.InternationalCup));
            AddMenuButton(buttons, "CHAMPIONS CUP", 2,
                () => game.RequestTeamSelection(CompetitionType.ChampionsCup));
            AddMenuButton(buttons, "16-STAGE JOURNEY", 3,
                () => game.RequestTeamSelection(CompetitionType.Journey));
            AddMenuButton(buttons, "TEAMS", 4, ShowTeamBrowser);
            AddMenuButton(buttons, "SETTINGS", 5, ShowSettings);

            RectTransform card = UIFactory.Panel(root, "Feature Card", new Color(0.045f, 0.12f, 0.2f, 0.93f),
                new Vector2(0.57f, 0.14f), new Vector2(0.92f, 0.72f), Vector2.zero, Vector2.zero);
            UIFactory.Text(card, "PLAY ANYWHERE", 36, FontStyle.Bold, TextAnchor.MiddleCenter, cyan,
                new Vector2(0.08f, 0.78f), new Vector2(0.92f, 0.94f), Vector2.zero, Vector2.zero);
            string info = "KEYBOARD + GAMEPAD + TOUCH\n\n211 NATIONAL TEAMS\n36 ORIGINAL CLUBS\n\nBROADCAST CAMERA\nTOURNAMENT PROGRESSION\nPROCEDURAL 3D STADIUM";
            UIFactory.Text(card, info, 24, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white,
                new Vector2(0.08f, 0.14f), new Vector2(0.92f, 0.78f), Vector2.zero, Vector2.zero);
            UIFactory.Button(card, "HOW TO PLAY", ShowTutorial, new Vector2(0.25f, 0.025f),
                new Vector2(0.75f, 0.14f), Vector2.zero, Vector2.zero,
                new Color(0.08f, 0.3f, 0.44f, 1f), 20);
            UIFactory.Text(root,
                $"Matches {SaveSystem.Data.MatchesPlayed}   Wins {SaveSystem.Data.Wins}   Goals {SaveSystem.Data.Goals}",
                22, FontStyle.Normal, TextAnchor.MiddleRight, new Color(0.65f, 0.78f, 0.9f),
                new Vector2(0.55f, 0.05f), new Vector2(0.92f, 0.11f), Vector2.zero, Vector2.zero);
        }

        public void ShowTeamSelection(CompetitionType type, IReadOnlyList<TeamData> teams,
            Action<TeamData> onSelected)
        {
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            string title = type switch
            {
                CompetitionType.ChampionsCup => "SELECT YOUR CLUB",
                CompetitionType.Journey => "SELECT YOUR JOURNEY TEAM",
                _ => "SELECT YOUR NATIONAL TEAM"
            };
            UIFactory.Text(root, title, 48, FontStyle.Bold, TextAnchor.MiddleLeft, Color.white,
                new Vector2(0.06f, 0.88f), new Vector2(0.8f, 0.97f), Vector2.zero, Vector2.zero);
            UIFactory.Button(root, "BACK", ShowMainMenu, new Vector2(0.82f, 0.88f), new Vector2(0.94f, 0.96f),
                Vector2.zero, Vector2.zero, new Color(0.16f, 0.22f, 0.31f, 1f), 22);
            UIFactory.ScrollList(root, out RectTransform content, new Vector2(0.06f, 0.08f),
                new Vector2(0.94f, 0.86f), Vector2.zero, Vector2.zero);

            foreach (TeamData team in teams)
            {
                TeamData captured = team;
                Button button = UIFactory.Button(content,
                    $"{team.DisplayName}     {team.Confederation}     RATING {team.Rating}",
                    () => onSelected(captured), Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero,
                    new Color(team.Primary.r * 0.55f + 0.08f, team.Primary.g * 0.55f + 0.08f,
                        team.Primary.b * 0.55f + 0.08f, 0.98f), 22);
                UIFactory.Layout(button.gameObject, 64f);
            }
        }

        public void ShowCompetitionHub(CompetitionSession session, TeamData team, TeamData opponent,
            Action playNext, Action abandon, Action showTable)
        {
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Text(root, session.Type.ToString().ToUpperInvariant(), 52, FontStyle.Bold,
                TextAnchor.MiddleCenter, cyan, new Vector2(0.1f, 0.78f), new Vector2(0.9f, 0.94f),
                Vector2.zero, Vector2.zero);
            RectTransform card = UIFactory.Panel(root, "Competition Card", new Color(0.04f, 0.1f, 0.18f, 1f),
                new Vector2(0.18f, 0.23f), new Vector2(0.82f, 0.77f), Vector2.zero, Vector2.zero);
            UIFactory.Text(card, session.StageLabel, 34, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white,
                new Vector2(0.08f, 0.77f), new Vector2(0.92f, 0.94f), Vector2.zero, Vector2.zero);
            UIFactory.Text(card, $"{team.DisplayName}\nVS\n{opponent.DisplayName}", 42, FontStyle.Bold,
                TextAnchor.MiddleCenter, Color.white, new Vector2(0.08f, 0.34f), new Vector2(0.92f, 0.75f),
                Vector2.zero, Vector2.zero);
            UIFactory.Text(card,
                $"W {session.Wins}   D {session.Draws}   L {session.Losses}   PTS {session.Points}\nGOALS {session.GoalsFor}:{session.GoalsAgainst}",
                23, FontStyle.Normal, TextAnchor.MiddleCenter, new Color(0.65f, 0.78f, 0.9f),
                new Vector2(0.1f, 0.14f), new Vector2(0.9f, 0.35f), Vector2.zero, Vector2.zero);
            UIFactory.Button(root, "PLAY NEXT MATCH", () => playNext(), new Vector2(0.32f, 0.1f),
                new Vector2(0.68f, 0.2f), Vector2.zero, Vector2.zero, cyan, 28);
            if (session.Standings.Count > 0)
                UIFactory.Button(root, "TABLE", () => showTable(), new Vector2(0.7f, 0.1f),
                    new Vector2(0.84f, 0.2f), Vector2.zero, Vector2.zero,
                    new Color(0.12f, 0.34f, 0.48f, 1f), 22);
            UIFactory.Button(root, "ABANDON", () => abandon(), new Vector2(0.42f, 0.02f),
                new Vector2(0.58f, 0.085f), Vector2.zero, Vector2.zero,
                new Color(0.18f, 0.22f, 0.3f, 1f), 19);
        }

        public void ShowStandings(CompetitionSession session, Action goBack)
        {
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            string title = session.Type == CompetitionType.InternationalCup
                ? "GROUP TABLE"
                : "36-CLUB LEAGUE TABLE";
            string note = session.Type == CompetitionType.InternationalCup
                ? "Top two advance; third place needs at least four points in this prototype"
                : "Top 8 reach the round of 16; positions 9-24 enter the play-off";
            UIFactory.Text(root, title, 48, FontStyle.Bold, TextAnchor.MiddleLeft, Color.white,
                new Vector2(0.06f, 0.88f), new Vector2(0.72f, 0.97f), Vector2.zero, Vector2.zero);
            UIFactory.Text(root, note, 21, FontStyle.Normal, TextAnchor.MiddleLeft,
                new Color(0.65f, 0.78f, 0.9f), new Vector2(0.06f, 0.83f), new Vector2(0.8f, 0.89f),
                Vector2.zero, Vector2.zero);
            UIFactory.Button(root, "BACK", () => goBack(), new Vector2(0.82f, 0.88f),
                new Vector2(0.94f, 0.96f), Vector2.zero, Vector2.zero,
                new Color(0.16f, 0.22f, 0.31f, 1f), 22);
            UIFactory.Text(root, "#   TEAM                         P     W     D     L     GD     PTS", 20,
                FontStyle.Bold, TextAnchor.MiddleLeft, cyan, new Vector2(0.08f, 0.77f),
                new Vector2(0.92f, 0.83f), Vector2.zero, Vector2.zero);
            UIFactory.ScrollList(root, out RectTransform content, new Vector2(0.06f, 0.08f),
                new Vector2(0.94f, 0.77f), Vector2.zero, Vector2.zero);

            IEnumerable<StandingRow> visible = session.Type == CompetitionType.InternationalCup
                ? session.Standings.Where(x => session.UserGroupIds.Contains(x.TeamId))
                : session.Standings;
            List<StandingRow> ordered = visible.OrderByDescending(x => x.Points)
                .ThenByDescending(x => x.GoalDifference)
                .ThenByDescending(x => x.GoalsFor)
                .ThenBy(x => TeamCatalog.Find(x.TeamId).DisplayName)
                .ToList();
            for (int i = 0; i < ordered.Count; i++)
            {
                StandingRow row = ordered[i];
                TeamData rowTeam = TeamCatalog.Find(row.TeamId);
                bool isUser = row.TeamId == session.UserTeamId;
                string line = $"{i + 1,2}   {Truncate(rowTeam.DisplayName, 25),-25}   {row.Played,2}    " +
                              $"{row.Wins,2}    {row.Draws,2}    {row.Losses,2}    {row.GoalDifference,3}     {row.Points,3}";
                RectTransform item = UIFactory.Panel(content, rowTeam.DisplayName,
                    isUser ? new Color(0.02f, 0.52f, 0.72f, 0.95f) : new Color(0.07f, 0.13f, 0.21f, 0.96f),
                    Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
                UIFactory.Layout(item.gameObject, 52f);
                UIFactory.Text(item, line, 19, isUser ? FontStyle.Bold : FontStyle.Normal,
                    TextAnchor.MiddleLeft, Color.white, new Vector2(0.025f, 0f), new Vector2(0.975f, 1f),
                    Vector2.zero, Vector2.zero);
            }
        }

        public void ShowMatchResult(CompetitionSession session, TeamData home, TeamData away,
            int homeGoals, int awayGoals, string headline, bool canContinue, Action continueAction)
        {
            SetVisible(true);
            Clear();
            UIFactory.Panel(root, "Backdrop", new Color(0.01f, 0.025f, 0.06f, 0.985f), Vector2.zero,
                Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Text(root, headline, 52, FontStyle.Bold, TextAnchor.MiddleCenter,
                canContinue ? cyan : new Color(1f, 0.35f, 0.3f), new Vector2(0.1f, 0.73f),
                new Vector2(0.9f, 0.9f), Vector2.zero, Vector2.zero);
            UIFactory.Text(root, $"{home.DisplayName}   {homeGoals}  -  {awayGoals}   {away.DisplayName}",
                42, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white, new Vector2(0.05f, 0.5f),
                new Vector2(0.95f, 0.72f), Vector2.zero, Vector2.zero);
            UIFactory.Text(root,
                $"{session.StageLabel}\nW {session.Wins}   D {session.Draws}   L {session.Losses}   PTS {session.Points}",
                25, FontStyle.Normal, TextAnchor.MiddleCenter, new Color(0.65f, 0.78f, 0.9f),
                new Vector2(0.12f, 0.32f), new Vector2(0.88f, 0.49f), Vector2.zero, Vector2.zero);
            UIFactory.Button(root, canContinue ? "CONTINUE" : "MAIN MENU",
                canContinue ? () => continueAction() : ShowMainMenu, new Vector2(0.34f, 0.17f),
                new Vector2(0.66f, 0.29f), Vector2.zero, Vector2.zero, cyan, 30);
            if (canContinue)
                UIFactory.Button(root, "MAIN MENU", ShowMainMenu, new Vector2(0.41f, 0.08f),
                    new Vector2(0.59f, 0.15f), Vector2.zero, Vector2.zero,
                    new Color(0.18f, 0.22f, 0.3f, 1f), 19);
        }

        private void ShowTeamBrowser()
        {
            ShowTeamSelection(CompetitionType.InternationalCup, TeamCatalog.NationalTeams, team =>
            {
                Clear();
                UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
                UIFactory.Text(root, team.DisplayName, 60, FontStyle.Bold, TextAnchor.MiddleCenter, team.Primary,
                    new Vector2(0.08f, 0.6f), new Vector2(0.92f, 0.82f), Vector2.zero, Vector2.zero);
                UIFactory.Text(root, $"CONFEDERATION {team.Confederation}\nTEAM RATING {team.Rating}", 32,
                    FontStyle.Bold, TextAnchor.MiddleCenter, Color.white, new Vector2(0.1f, 0.36f),
                    new Vector2(0.9f, 0.58f), Vector2.zero, Vector2.zero);
                UIFactory.Button(root, "BACK TO TEAMS", ShowTeamBrowser, new Vector2(0.35f, 0.18f),
                    new Vector2(0.65f, 0.29f), Vector2.zero, Vector2.zero, cyan, 25);
            });
        }

        private void ShowSettings()
        {
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Text(root, "SETTINGS", 56, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white,
                new Vector2(0.1f, 0.78f), new Vector2(0.9f, 0.94f), Vector2.zero, Vector2.zero);
            UIFactory.Text(root, "GRAPHICS", 25, FontStyle.Bold, TextAnchor.MiddleLeft, cyan,
                new Vector2(0.24f, 0.64f), new Vector2(0.76f, 0.72f), Vector2.zero, Vector2.zero);
            string[] presets = { "MOBILE", "BALANCED", "ULTRA" };
            for (int i = 0; i < presets.Length; i++)
            {
                int captured = i;
                float x = 0.24f + i * 0.18f;
                Color color = SaveSystem.Data.GraphicsPreset == i ? cyan : new Color(0.16f, 0.22f, 0.31f, 1f);
                UIFactory.Button(root, presets[i], () =>
                {
                    SaveSystem.Data.GraphicsPreset = captured;
                    SaveSystem.ApplySettings();
                    SaveSystem.Save();
                    ShowSettings();
                }, new Vector2(x, 0.54f), new Vector2(x + 0.16f, 0.63f), Vector2.zero, Vector2.zero, color, 21);
            }

            UIFactory.Text(root, "MASTER VOLUME", 25, FontStyle.Bold, TextAnchor.MiddleLeft, cyan,
                new Vector2(0.24f, 0.41f), new Vector2(0.76f, 0.49f), Vector2.zero, Vector2.zero);
            UIFactory.Slider(root, SaveSystem.Data.MasterVolume, value =>
            {
                SaveSystem.Data.MasterVolume = value;
                AudioListener.volume = value;
                SaveSystem.Save();
            }, new Vector2(0.24f, 0.35f), new Vector2(0.76f, 0.39f), Vector2.zero, Vector2.zero);

            string touchLabel = SaveSystem.Data.ShowTouchControlsOnDesktop
                ? "DESKTOP TOUCH OVERLAY: ON"
                : "DESKTOP TOUCH OVERLAY: OFF";
            UIFactory.Button(root, touchLabel, () =>
            {
                SaveSystem.Data.ShowTouchControlsOnDesktop = !SaveSystem.Data.ShowTouchControlsOnDesktop;
                SaveSystem.Save();
                ShowSettings();
            }, new Vector2(0.32f, 0.22f), new Vector2(0.68f, 0.31f), Vector2.zero, Vector2.zero,
                new Color(0.16f, 0.22f, 0.31f, 1f), 21);
            UIFactory.Button(root, "BACK", ShowMainMenu, new Vector2(0.4f, 0.08f),
                new Vector2(0.6f, 0.17f), Vector2.zero, Vector2.zero, cyan, 24);
        }

        private void ShowTutorial()
        {
            Clear();
            UIFactory.Panel(root, "Backdrop", navy, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Text(root, "HOW TO PLAY", 56, FontStyle.Bold, TextAnchor.MiddleCenter, cyan,
                new Vector2(0.1f, 0.8f), new Vector2(0.9f, 0.94f), Vector2.zero, Vector2.zero);
            string guide =
                "MOVE\nWASD / ARROWS   •   LEFT STICK   •   TOUCH STICK\n\n" +
                "PASS: J or SPACE   •   SHOOT: K   •   SPRINT: SHIFT\n" +
                "SWITCH PLAYER: Q or L   •   PAUSE: ESC\n\n" +
                "On gamepad use South to pass, West to shoot and shoulder buttons to sprint/switch.\n" +
                "On Android the same actions appear as buttons. Win Journey matches to unlock all 16 stages.";
            RectTransform card = UIFactory.Panel(root, "Tutorial Card", new Color(0.04f, 0.1f, 0.18f, 1f),
                new Vector2(0.16f, 0.22f), new Vector2(0.84f, 0.78f), Vector2.zero, Vector2.zero);
            UIFactory.Text(card, guide, 25, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white,
                new Vector2(0.07f, 0.08f), new Vector2(0.93f, 0.92f), Vector2.zero, Vector2.zero);
            UIFactory.Button(root, "BACK", ShowMainMenu, new Vector2(0.4f, 0.08f),
                new Vector2(0.6f, 0.17f), Vector2.zero, Vector2.zero, cyan, 24);
        }

        private void AddMenuButton(Transform parent, string label, int index, Action action)
        {
            float top = 1f - index * 0.16f;
            UIFactory.Button(parent, label, () => action(), new Vector2(0f, top - 0.135f),
                new Vector2(1f, top - 0.02f), Vector2.zero, Vector2.zero,
                index < 4 ? new Color(0.04f, 0.42f + index * 0.035f, 0.72f + index * 0.025f, 0.98f)
                    : new Color(0.14f, 0.2f, 0.29f, 1f), 25);
        }

        private static string Truncate(string value, int length)
        {
            return value.Length <= length ? value : value.Substring(0, length - 1) + "…";
        }

        private void Clear()
        {
            for (int i = root.childCount - 1; i >= 0; i--)
                UnityEngine.Object.Destroy(root.GetChild(i).gameObject);
        }
    }
}
