using System;
using UnityEngine;
using UnityEngine.UI;

namespace GlobalFootball
{
    public sealed class MatchHUD
    {
        private readonly Canvas canvas;
        private readonly RectTransform root;
        private readonly Text scoreText;
        private readonly Text clockText;
        private readonly Text bannerText;
        private readonly RectTransform touchRoot;
        private RectTransform pauseRoot;

        public MatchHUD(string homeName, string awayName, string stageLabel, Action pauseAction)
        {
            canvas = UIFactory.CreateCanvas("Match HUD", 20);
            root = canvas.GetComponent<RectTransform>();
            RectTransform scoreboard = UIFactory.Panel(root, "Scoreboard", new Color(0.015f, 0.035f, 0.075f, 0.94f),
                new Vector2(0.31f, 0.9f), new Vector2(0.69f, 0.985f), Vector2.zero, Vector2.zero);
            scoreText = UIFactory.Text(scoreboard, $"{homeName}   0 - 0   {awayName}", 25, FontStyle.Bold,
                TextAnchor.MiddleCenter, Color.white, new Vector2(0f, 0f), new Vector2(0.76f, 1f),
                new Vector2(10f, 0f), Vector2.zero);
            clockText = UIFactory.Text(scoreboard, "00:00", 24, FontStyle.Bold, TextAnchor.MiddleCenter,
                new Color(0.04f, 0.82f, 1f), new Vector2(0.76f, 0f), new Vector2(1f, 1f),
                Vector2.zero, Vector2.zero);
            UIFactory.Text(root, stageLabel, 20, FontStyle.Bold, TextAnchor.MiddleLeft, Color.white,
                new Vector2(0.025f, 0.92f), new Vector2(0.3f, 0.98f), Vector2.zero, Vector2.zero);
            UIFactory.Button(root, "II", () => pauseAction(), new Vector2(0.925f, 0.91f),
                new Vector2(0.975f, 0.98f), Vector2.zero, Vector2.zero,
                new Color(0.03f, 0.12f, 0.2f, 0.9f), 22);
            bannerText = UIFactory.Text(root, string.Empty, 48, FontStyle.Bold, TextAnchor.MiddleCenter,
                Color.white, new Vector2(0.2f, 0.68f), new Vector2(0.8f, 0.82f), Vector2.zero, Vector2.zero);

            bool showTouch = Application.isMobilePlatform || SaveSystem.Data.ShowTouchControlsOnDesktop;
            touchRoot = UIFactory.Panel(root, "Touch Controls", Color.clear, Vector2.zero, Vector2.one,
                Vector2.zero, Vector2.zero);
            touchRoot.gameObject.SetActive(showTouch);
            BuildTouchControls(touchRoot);

            if (!showTouch)
            {
                UIFactory.Text(root, "WASD / ARROWS  Move    SHIFT  Sprint    J / SPACE  Pass    K  Shoot    Q / L  Switch",
                    18, FontStyle.Bold, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.76f),
                    new Vector2(0.17f, 0.02f), new Vector2(0.83f, 0.065f), Vector2.zero, Vector2.zero);
            }
        }

        public void UpdateScore(string homeName, string awayName, int home, int away)
        {
            scoreText.text = $"{homeName}   {home} - {away}   {awayName}";
        }

        public void UpdateClock(float elapsedNormalized, bool extraTime)
        {
            float minutes = (extraTime ? 90f : 0f) + Mathf.Clamp01(elapsedNormalized) * (extraTime ? 30f : 90f);
            int whole = Mathf.FloorToInt(minutes);
            int seconds = Mathf.FloorToInt((minutes - whole) * 60f);
            clockText.text = $"{whole:00}:{seconds:00}";
        }

        public void ShowBanner(string value, Color color)
        {
            bannerText.text = value;
            bannerText.color = color;
        }

        public void ClearBanner() => bannerText.text = string.Empty;

        public void ShowPause(Action resume, Action forfeit)
        {
            if (pauseRoot != null)
                UnityEngine.Object.Destroy(pauseRoot.gameObject);
            pauseRoot = UIFactory.Panel(root, "Pause Overlay", new Color(0.01f, 0.02f, 0.05f, 0.94f),
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            UIFactory.Text(pauseRoot, "PAUSED", 58, FontStyle.Bold, TextAnchor.MiddleCenter, Color.white,
                new Vector2(0.2f, 0.62f), new Vector2(0.8f, 0.82f), Vector2.zero, Vector2.zero);
            UIFactory.Button(pauseRoot, "RESUME", () => resume(), new Vector2(0.35f, 0.43f),
                new Vector2(0.65f, 0.54f), Vector2.zero, Vector2.zero,
                new Color(0.02f, 0.65f, 0.92f, 1f), 29);
            UIFactory.Button(pauseRoot, "FORFEIT MATCH", () => forfeit(), new Vector2(0.38f, 0.3f),
                new Vector2(0.62f, 0.39f), Vector2.zero, Vector2.zero,
                new Color(0.5f, 0.12f, 0.14f, 1f), 22);
        }

        public void HidePause()
        {
            if (pauseRoot == null)
                return;
            UnityEngine.Object.Destroy(pauseRoot.gameObject);
            pauseRoot = null;
        }

        public void Dispose()
        {
            UnifiedInput.ResetTouch();
            if (canvas != null)
                UnityEngine.Object.Destroy(canvas.gameObject);
        }

        private static void BuildTouchControls(Transform parent)
        {
            RectTransform stickBase = UIFactory.Panel(parent, "Move Stick", new Color(0.08f, 0.16f, 0.25f, 0.58f),
                new Vector2(0.04f, 0.06f), new Vector2(0.19f, 0.31f), Vector2.zero, Vector2.zero);
            Image image = stickBase.GetComponent<Image>();
            image.raycastTarget = true;
            RectTransform knob = UIFactory.Panel(stickBase, "Knob", new Color(0.1f, 0.78f, 1f, 0.82f),
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-43f, -43f),
                new Vector2(43f, 43f));
            TouchStick stick = stickBase.gameObject.AddComponent<TouchStick>();
            stick.Knob = knob;
            stick.Radius = 72f;

            ActionButton(parent, "PASS", TouchAction.Pass, new Vector2(0.78f, 0.08f),
                new Vector2(0.89f, 0.25f), new Color(0.03f, 0.55f, 0.92f, 0.78f));
            ActionButton(parent, "SHOOT", TouchAction.Shoot, new Vector2(0.88f, 0.19f),
                new Vector2(0.98f, 0.36f), new Color(0.9f, 0.24f, 0.18f, 0.82f));
            ActionButton(parent, "SPRINT", TouchAction.Sprint, new Vector2(0.67f, 0.2f),
                new Vector2(0.77f, 0.36f), new Color(0.95f, 0.63f, 0.08f, 0.78f));
            ActionButton(parent, "SWITCH", TouchAction.Switch, new Vector2(0.84f, 0.39f),
                new Vector2(0.94f, 0.53f), new Color(0.4f, 0.2f, 0.76f, 0.78f), 17);
        }

        private static void ActionButton(Transform parent, string label, TouchAction action,
            Vector2 anchorMin, Vector2 anchorMax, Color color, int fontSize = 20)
        {
            Button button = UIFactory.Button(parent, label, null, anchorMin, anchorMax, Vector2.zero,
                Vector2.zero, color, fontSize);
            TouchActionButton touch = button.gameObject.AddComponent<TouchActionButton>();
            touch.Action = action;
        }
    }
}
