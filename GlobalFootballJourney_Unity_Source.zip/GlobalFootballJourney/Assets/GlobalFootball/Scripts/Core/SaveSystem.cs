using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace GlobalFootball
{
    public static class SaveSystem
    {
        private const string Key = "global_football_journey_save_v1";
        public static SaveData Data { get; private set; }

        public static void Load()
        {
            string json = PlayerPrefs.GetString(Key, string.Empty);
            Data = string.IsNullOrWhiteSpace(json)
                ? new SaveData()
                : JsonUtility.FromJson<SaveData>(json) ?? new SaveData();
            ApplySettings();
        }

        public static void Save()
        {
            if (Data == null)
                Data = new SaveData();
            PlayerPrefs.SetString(Key, JsonUtility.ToJson(Data));
            PlayerPrefs.Save();
        }

        public static void RecordMatch(int userGoals, int opponentGoals, CompetitionType type, int stage)
        {
            Data.MatchesPlayed++;
            Data.Goals += userGoals;
            if (userGoals > opponentGoals)
                Data.Wins++;
            if (type == CompetitionType.Journey && userGoals > opponentGoals)
                Data.JourneyUnlocked = Mathf.Max(Data.JourneyUnlocked, Mathf.Min(16, stage + 2));
            Save();
        }

        public static void ApplySettings()
        {
            if (Data == null)
                return;

            AudioListener.volume = Mathf.Clamp01(Data.MasterVolume);
            QualitySettings.vSyncCount = 0;
            float shadowDistance;
            int antiAliasing;
            float renderScale;
            switch (Mathf.Clamp(Data.GraphicsPreset, 0, 2))
            {
                case 0:
                    shadowDistance = 35f;
                    antiAliasing = 1;
                    renderScale = 0.82f;
                    Application.targetFrameRate = 60;
                    break;
                case 1:
                    shadowDistance = 70f;
                    antiAliasing = 2;
                    renderScale = 1f;
                    Application.targetFrameRate = 60;
                    break;
                default:
                    shadowDistance = 110f;
                    antiAliasing = 4;
                    renderScale = 1.12f;
                    Application.targetFrameRate = 120;
                    break;
            }

            QualitySettings.shadowDistance = shadowDistance;
            QualitySettings.antiAliasing = antiAliasing == 1 ? 0 : antiAliasing;
            if (GraphicsSettings.currentRenderPipeline is UniversalRenderPipelineAsset urp)
            {
                urp.shadowDistance = shadowDistance;
                urp.msaaSampleCount = antiAliasing;
                urp.renderScale = renderScale;
            }
        }
    }
}
