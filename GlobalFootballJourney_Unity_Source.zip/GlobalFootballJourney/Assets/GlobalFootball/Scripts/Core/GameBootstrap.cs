using UnityEngine;

namespace GlobalFootball
{
    public static class GameBootstrap
    {
        private static bool booted;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
        private static void Boot()
        {
            if (booted)
                return;
            booted = true;
            GameObject root = new GameObject("Global Football Journey");
            root.AddComponent<GameRoot>();
        }
    }
}
