using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;

namespace GlobalFootball
{
    public sealed class GameRoot : MonoBehaviour
    {
        private GameUI ui;
        private CompetitionSession session;
        private TeamData userTeam;
        private TeamData currentOpponent;
        private GameObject matchHost;
        private int sessionSeed;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            SaveSystem.Load();
            EnsureEventSystem();
            _ = TeamCatalog.NationalTeams.Count;
            _ = TeamCatalog.ClubTeams.Count;
            ui = new GameUI(this);
            ui.ShowMainMenu();
        }

        public void RequestTeamSelection(CompetitionType type)
        {
            IReadOnlyList<TeamData> teams = type == CompetitionType.ChampionsCup
                ? TeamCatalog.ClubTeams
                : TeamCatalog.NationalTeams;
            ui.ShowTeamSelection(type, teams, selected => CreateSession(type, selected));
        }

        private void CreateSession(CompetitionType type, TeamData selected)
        {
            userTeam = selected;
            sessionSeed = Environment.TickCount ^ selected.Id.GetHashCode();
            session = new CompetitionSession
            {
                Type = type,
                UserTeamId = selected.Id,
                StageIndex = type == CompetitionType.Journey
                    ? Mathf.Clamp(SaveSystem.Data.JourneyUnlocked - 1, 0, 15)
                    : 0
            };
            List<TeamData> opponents = TeamCatalog.PickOpponents(type, selected.Id,
                session.TotalStages, sessionSeed);
            session.OpponentIds = opponents.Select(x => x.Id).ToList();
            InitializeCompetitionTable(type, selected, opponents);
            ShowCompetitionHub();
        }

        private void ShowCompetitionHub()
        {
            if (session == null || session.OpponentIds.Count == 0)
            {
                ui.ShowMainMenu();
                return;
            }
            int index = Mathf.Clamp(session.StageIndex, 0, session.OpponentIds.Count - 1);
            currentOpponent = TeamCatalog.Find(session.OpponentIds[index]);
            ui.ShowCompetitionHub(session, userTeam, currentOpponent, StartCurrentMatch, AbandonSession,
                () => ui.ShowStandings(session, ShowCompetitionHub));
        }

        private void StartCurrentMatch()
        {
            if (matchHost != null)
                Destroy(matchHost);
            ui.SetVisible(false);
            UnifiedInput.ResetTouch();
            matchHost = new GameObject("Active Match");
            MatchController match = matchHost.AddComponent<MatchController>();
            float difficulty = Mathf.Clamp(0.72f + session.StageIndex * 0.035f +
                                           (currentOpponent.Rating - userTeam.Rating) * 0.006f, 0.55f, 1.35f);
            match.Initialize(userTeam, currentOpponent, session.Type, session.StageLabel, difficulty,
                OnMatchFinished);
        }

        private void OnMatchFinished(int userGoals, int opponentGoals)
        {
            int playedStage = session.StageIndex;
            SaveSystem.RecordMatch(userGoals, opponentGoals, session.Type, playedStage);
            session.GoalsFor += userGoals;
            session.GoalsAgainst += opponentGoals;
            bool win = userGoals > opponentGoals;
            bool draw = userGoals == opponentGoals;
            if (win)
            {
                session.Wins++;
                session.Points += 3;
            }
            else if (draw)
            {
                session.Draws++;
                session.Points += 1;
            }
            else
            {
                session.Losses++;
            }

            if (IsLeagueStage(session.Type, playedStage))
            {
                RecordTableResult(userTeam.Id, currentOpponent.Id, userGoals, opponentGoals);
                SimulateLeagueRound(playedStage, currentOpponent.Id);
            }

            if (matchHost != null)
            {
                Destroy(matchHost);
                matchHost = null;
            }

            string headline;
            bool canContinue;
            bool advance = false;

            if (session.Type == CompetitionType.QuickMatch)
            {
                headline = win ? "VICTORY" : draw ? "DRAW" : "FULL TIME";
                canContinue = false;
            }
            else if (session.Type == CompetitionType.Journey)
            {
                if (win)
                {
                    session.StageIndex++;
                    advance = true;
                    bool completed = session.StageIndex >= session.TotalStages;
                    headline = completed ? "JOURNEY COMPLETE" : "STAGE CLEARED";
                    canContinue = !completed;
                }
                else
                {
                    headline = "RETRY THIS STAGE";
                    canContinue = true;
                }
            }
            else
            {
                int leagueBoundary = session.Type == CompetitionType.InternationalCup ? 3 : 8;
                if (session.StageIndex < leagueBoundary)
                {
                    session.StageIndex++;
                    advance = true;
                    bool leagueEnded = session.StageIndex == leagueBoundary;
                    int rank = leagueEnded ? GetUserTableRank() : 0;
                    bool qualified = session.Type == CompetitionType.InternationalCup
                        ? rank <= 2 || (rank == 3 && session.Points >= 4)
                        : rank <= 24;
                    if (leagueEnded && !qualified)
                    {
                        session.Eliminated = true;
                        headline = "ELIMINATED";
                        canContinue = false;
                    }
                    else
                    {
                        if (leagueEnded && session.Type == CompetitionType.ChampionsCup && rank <= 8)
                        {
                            session.StageIndex = 9;
                            headline = "TOP 8 - ROUND OF 16";
                        }
                        else if (leagueEnded && session.Type == CompetitionType.ChampionsCup)
                        {
                            headline = "KNOCKOUT PLAY-OFF";
                        }
                        else if (leagueEnded)
                        {
                            headline = "ROUND OF 32 QUALIFIED";
                        }
                        else
                        {
                            headline = win ? "MATCH WON" : draw ? "POINT EARNED" : "NEXT MATCH";
                        }
                        canContinue = true;
                    }
                }
                else if (win)
                {
                    session.StageIndex++;
                    advance = true;
                    bool champion = session.StageIndex >= session.TotalStages;
                    headline = champion ? "CHAMPIONS" : "QUALIFIED";
                    canContinue = !champion;
                }
                else
                {
                    session.Eliminated = true;
                    headline = "ELIMINATED";
                    canContinue = false;
                }
            }

            Action continueAction = () =>
            {
                if (advance && session.StageIndex >= session.OpponentIds.Count)
                    ui.ShowMainMenu();
                else
                    ShowCompetitionHub();
            };
            ui.ShowMatchResult(session, userTeam, currentOpponent, userGoals, opponentGoals,
                headline, canContinue, continueAction);
        }

        private void AbandonSession()
        {
            session = null;
            userTeam = null;
            currentOpponent = null;
            ui.ShowMainMenu();
        }

        private void InitializeCompetitionTable(CompetitionType type, TeamData selected,
            IReadOnlyList<TeamData> opponents)
        {
            if (type == CompetitionType.InternationalCup)
            {
                session.UserGroupIds.Add(selected.Id);
                session.UserGroupIds.AddRange(opponents.Take(3).Select(x => x.Id));
                session.Standings = session.UserGroupIds.Select(id => new StandingRow(id)).ToList();
                return;
            }

            if (type == CompetitionType.ChampionsCup)
            {
                session.Standings = TeamCatalog.ClubTeams.Select(x => new StandingRow(x.Id)).ToList();
            }
        }

        private static bool IsLeagueStage(CompetitionType type, int stageIndex)
        {
            return type == CompetitionType.InternationalCup && stageIndex < 3 ||
                   type == CompetitionType.ChampionsCup && stageIndex < 8;
        }

        private void RecordTableResult(string homeId, string awayId, int homeGoals, int awayGoals)
        {
            StandingRow home = session.Standings.FirstOrDefault(x => x.TeamId == homeId);
            StandingRow away = session.Standings.FirstOrDefault(x => x.TeamId == awayId);
            home?.Record(homeGoals, awayGoals);
            away?.Record(awayGoals, homeGoals);
        }

        private void SimulateLeagueRound(int playedStage, string userOpponentId)
        {
            IEnumerable<string> ids = session.Type == CompetitionType.InternationalCup
                ? session.UserGroupIds
                : session.Standings.Select(x => x.TeamId);
            List<string> remaining = ids.Where(id => id != userTeam.Id && id != userOpponentId).ToList();
            var random = new System.Random(sessionSeed ^ ((playedStage + 1) * 7919));
            for (int i = remaining.Count - 1; i > 0; i--)
            {
                int swap = random.Next(i + 1);
                (remaining[i], remaining[swap]) = (remaining[swap], remaining[i]);
            }

            for (int i = 0; i + 1 < remaining.Count; i += 2)
            {
                string homeId = remaining[i];
                string awayId = remaining[i + 1];
                TeamData home = TeamCatalog.Find(homeId);
                TeamData away = TeamCatalog.Find(awayId);
                int homeGoals = SimulatedGoals(random, home.Rating, away.Rating, true);
                int awayGoals = SimulatedGoals(random, away.Rating, home.Rating, false);
                RecordTableResult(homeId, awayId, homeGoals, awayGoals);
            }
        }

        private static int SimulatedGoals(System.Random random, int attackRating, int defenceRating,
            bool homeAdvantage)
        {
            double strength = 1.15 + (attackRating - defenceRating) * 0.035 +
                              (homeAdvantage ? 0.22 : 0.0);
            int goals = 0;
            for (int chance = 0; chance < 5; chance++)
            {
                double probability = Math.Max(0.08, Math.Min(0.62, strength / 5.0));
                if (random.NextDouble() < probability)
                    goals++;
            }
            return goals;
        }

        private int GetUserTableRank()
        {
            IEnumerable<StandingRow> rows = session.Type == CompetitionType.InternationalCup
                ? session.Standings.Where(x => session.UserGroupIds.Contains(x.TeamId))
                : session.Standings;
            List<StandingRow> sorted = rows.OrderByDescending(x => x.Points)
                .ThenByDescending(x => x.GoalDifference)
                .ThenByDescending(x => x.GoalsFor)
                .ThenBy(x => TeamCatalog.Find(x.TeamId).DisplayName)
                .ToList();
            int index = sorted.FindIndex(x => x.TeamId == userTeam.Id);
            return index < 0 ? sorted.Count : index + 1;
        }

        private static void EnsureEventSystem()
        {
            if (EventSystem.current != null)
                return;
            GameObject eventSystem = new GameObject("Event System", typeof(EventSystem));
            eventSystem.AddComponent<InputSystemUIInputModule>();
            DontDestroyOnLoad(eventSystem);
        }
    }
}
