using System;
using System.Collections.Generic;
using UnityEngine;

namespace GlobalFootball
{
    public enum CompetitionType
    {
        QuickMatch,
        InternationalCup,
        ChampionsCup,
        Journey
    }

    public enum MatchPhase
    {
        PreKickoff,
        Playing,
        GoalPause,
        HalfTime,
        FullTime,
        Paused
    }

    [Serializable]
    public sealed class TeamData
    {
        public string Id;
        public string DisplayName;
        public string Confederation;
        public int Rating;
        public Color Primary;
        public Color Secondary;
        public bool IsClub;

        public TeamData(string id, string displayName, string confederation, int rating,
            Color primary, Color secondary, bool isClub = false)
        {
            Id = id;
            DisplayName = displayName;
            Confederation = confederation;
            Rating = rating;
            Primary = primary;
            Secondary = secondary;
            IsClub = isClub;
        }
    }

    [Serializable]
    public sealed class StandingRow
    {
        public string TeamId;
        public int Played;
        public int Wins;
        public int Draws;
        public int Losses;
        public int GoalsFor;
        public int GoalsAgainst;
        public int Points;

        public int GoalDifference => GoalsFor - GoalsAgainst;

        public StandingRow(string teamId)
        {
            TeamId = teamId;
        }

        public void Record(int goalsFor, int goalsAgainst)
        {
            Played++;
            GoalsFor += goalsFor;
            GoalsAgainst += goalsAgainst;
            if (goalsFor > goalsAgainst)
            {
                Wins++;
                Points += 3;
            }
            else if (goalsFor == goalsAgainst)
            {
                Draws++;
                Points++;
            }
            else
            {
                Losses++;
            }
        }
    }

    [Serializable]
    public sealed class CompetitionSession
    {
        public CompetitionType Type;
        public string UserTeamId;
        public int StageIndex;
        public int Wins;
        public int Draws;
        public int Losses;
        public int GoalsFor;
        public int GoalsAgainst;
        public int Points;
        public bool Eliminated;
        public List<string> OpponentIds = new List<string>();
        public List<string> UserGroupIds = new List<string>();
        public List<StandingRow> Standings = new List<StandingRow>();

        public int TotalStages => Type switch
        {
            CompetitionType.InternationalCup => 8,
            CompetitionType.ChampionsCup => 13,
            CompetitionType.Journey => 16,
            _ => 1
        };

        public string StageLabel
        {
            get
            {
                if (Type == CompetitionType.Journey)
                    return $"Journey Stage {Mathf.Clamp(StageIndex + 1, 1, 16)} / 16";

                if (Type == CompetitionType.InternationalCup)
                {
                    string[] labels =
                    {
                        "Group Match 1", "Group Match 2", "Group Match 3", "Round of 32",
                        "Round of 16", "Quarter-final", "Semi-final", "Final"
                    };
                    return labels[Mathf.Clamp(StageIndex, 0, labels.Length - 1)];
                }

                if (Type == CompetitionType.ChampionsCup)
                {
                    string[] labels =
                    {
                        "League Match 1", "League Match 2", "League Match 3", "League Match 4",
                        "League Match 5", "League Match 6", "League Match 7", "League Match 8",
                        "Knockout Play-off", "Round of 16", "Quarter-final", "Semi-final", "Final"
                    };
                    return labels[Mathf.Clamp(StageIndex, 0, labels.Length - 1)];
                }

                return "Quick Match";
            }
        }
    }

    [Serializable]
    public sealed class SaveData
    {
        public int JourneyUnlocked = 1;
        public int MatchesPlayed;
        public int Wins;
        public int Goals;
        public int GraphicsPreset = 1;
        public float MasterVolume = 0.85f;
        public bool ShowTouchControlsOnDesktop;
    }
}
