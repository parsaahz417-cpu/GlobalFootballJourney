using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GlobalFootball
{
    public static class TeamCatalog
    {
        private static List<TeamData> nationalTeams;
        private static List<TeamData> clubTeams;

        public static IReadOnlyList<TeamData> NationalTeams => nationalTeams ??= BuildNationalTeams();
        public static IReadOnlyList<TeamData> ClubTeams => clubTeams ??= BuildClubTeams();

        public static TeamData Find(string id)
        {
            TeamData team = NationalTeams.FirstOrDefault(x => x.Id == id);
            return team ?? ClubTeams.FirstOrDefault(x => x.Id == id) ?? NationalTeams[0];
        }

        public static List<TeamData> PickOpponents(CompetitionType type, string userTeamId, int count, int seed)
        {
            IReadOnlyList<TeamData> source = type == CompetitionType.ChampionsCup ? ClubTeams : NationalTeams;
            System.Random random = new System.Random(seed);
            List<TeamData> candidates = source.Where(x => x.Id != userTeamId).ToList();
            for (int i = candidates.Count - 1; i > 0; i--)
            {
                int j = random.Next(i + 1);
                (candidates[i], candidates[j]) = (candidates[j], candidates[i]);
            }
            return candidates.Take(Mathf.Min(count, candidates.Count)).ToList();
        }

        private static List<TeamData> BuildNationalTeams()
        {
            var result = new List<TeamData>(211);
            AddConfederation(result, "AFC", 67, new[]
            {
                "Afghanistan", "Australia", "Bahrain", "Bangladesh", "Bhutan", "Brunei Darussalam",
                "Cambodia", "China PR", "Chinese Taipei", "Guam", "Hong Kong, China", "India",
                "Indonesia", "Iran", "Iraq", "Japan", "Jordan", "Korea DPR", "Korea Republic",
                "Kuwait", "Kyrgyz Republic", "Laos", "Lebanon", "Macau", "Malaysia", "Maldives",
                "Mongolia", "Myanmar", "Nepal", "Oman", "Pakistan", "Palestine", "Philippines",
                "Qatar", "Saudi Arabia", "Singapore", "Sri Lanka", "Syria", "Tajikistan", "Thailand",
                "Timor-Leste", "Turkmenistan", "United Arab Emirates", "Uzbekistan", "Vietnam", "Yemen"
            });
            AddConfederation(result, "CAF", 66, new[]
            {
                "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde",
                "Cameroon", "Central African Republic", "Chad", "Comoros", "Congo", "DR Congo",
                "Cote d'Ivoire", "Djibouti", "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini",
                "Ethiopia", "Gabon", "Gambia", "Ghana", "Guinea", "Guinea-Bissau", "Kenya", "Lesotho",
                "Liberia", "Libya", "Madagascar", "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco",
                "Mozambique", "Namibia", "Niger", "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal",
                "Seychelles", "Sierra Leone", "Somalia", "South Africa", "South Sudan", "Sudan", "Tanzania",
                "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe"
            });
            AddConfederation(result, "CONCACAF", 65, new[]
            {
                "Anguilla", "Antigua and Barbuda", "Aruba", "Bahamas", "Barbados", "Belize", "Bermuda",
                "British Virgin Islands", "Canada", "Cayman Islands", "Costa Rica", "Cuba", "Curacao",
                "Dominica", "Dominican Republic", "El Salvador", "Grenada", "Guatemala", "Guyana", "Haiti",
                "Honduras", "Jamaica", "Mexico", "Montserrat", "Nicaragua", "Panama", "Puerto Rico",
                "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Suriname",
                "Trinidad and Tobago", "Turks and Caicos Islands", "United States", "US Virgin Islands"
            });
            AddConfederation(result, "CONMEBOL", 75, new[]
            {
                "Argentina", "Bolivia", "Brazil", "Chile", "Colombia", "Ecuador", "Paraguay", "Peru",
                "Uruguay", "Venezuela"
            });
            AddConfederation(result, "OFC", 61, new[]
            {
                "American Samoa", "Cook Islands", "Fiji", "New Caledonia", "New Zealand", "Papua New Guinea",
                "Samoa", "Solomon Islands", "Tahiti", "Tonga", "Vanuatu"
            });
            AddConfederation(result, "UEFA", 73, new[]
            {
                "Albania", "Andorra", "Armenia", "Austria", "Azerbaijan", "Belarus", "Belgium",
                "Bosnia and Herzegovina", "Bulgaria", "Croatia", "Cyprus", "Czechia", "Denmark", "England",
                "Estonia", "Faroe Islands", "Finland", "France", "Georgia", "Germany", "Gibraltar", "Greece",
                "Hungary", "Iceland", "Israel", "Italy", "Kazakhstan", "Kosovo", "Latvia", "Liechtenstein",
                "Lithuania", "Luxembourg", "Malta", "Moldova", "Montenegro", "Netherlands", "North Macedonia",
                "Northern Ireland", "Norway", "Poland", "Portugal", "Republic of Ireland", "Romania", "Russia",
                "San Marino", "Scotland", "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland",
                "Turkiye", "Ukraine", "Wales"
            });

            ApplyRecognisableRatings(result);
            if (result.Count != 211)
                Debug.LogError($"National team catalog expected 211 entries but contains {result.Count}.");
            return result;
        }

        private static void AddConfederation(List<TeamData> target, string confederation, int baseRating,
            IEnumerable<string> names)
        {
            foreach (string name in names)
            {
                uint hash = StableHash(name);
                int rating = Mathf.Clamp(baseRating + (int)(hash % 13) - 5, 48, 87);
                float hue = (hash % 1000) / 1000f;
                Color primary = Color.HSVToRGB(hue, 0.72f, 0.9f);
                Color secondary = Color.HSVToRGB((hue + 0.42f) % 1f, 0.45f, 0.98f);
                string id = $"NAT-{confederation}-{target.Count:000}";
                target.Add(new TeamData(id, name, confederation, rating, primary, secondary));
            }
        }

        private static void ApplyRecognisableRatings(List<TeamData> teams)
        {
            var ratings = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase)
            {
                ["Argentina"] = 91, ["Brazil"] = 90, ["France"] = 90, ["Spain"] = 89,
                ["England"] = 88, ["Portugal"] = 88, ["Germany"] = 87, ["Netherlands"] = 87,
                ["Italy"] = 86, ["Belgium"] = 85, ["Uruguay"] = 85, ["Croatia"] = 84,
                ["Morocco"] = 84, ["Colombia"] = 84, ["Japan"] = 82, ["Iran"] = 80,
                ["Korea Republic"] = 81, ["United States"] = 80, ["Mexico"] = 80,
                ["Australia"] = 79, ["Senegal"] = 82, ["Nigeria"] = 81
            };
            foreach (TeamData team in teams)
                if (ratings.TryGetValue(team.DisplayName, out int value))
                    team.Rating = value;
        }

        private static List<TeamData> BuildClubTeams()
        {
            string[] names =
            {
                "London Royals", "North London Forge", "Manchester Comets", "Liverpool Tides",
                "Madrid Galacticos", "Madrid Crimson", "Barcelona Harbor", "Seville Suns",
                "Munich Eagles", "Dortmund Steel", "Leverkusen Pulse", "Frankfurt Crown",
                "Milan Vipers", "Milan Azure", "Turin Guardians", "Naples Volcano",
                "Paris Lumiere", "Marseille Waves", "Monaco Orbit", "Lyon Pride",
                "Lisbon Navigators", "Lisbon Lions", "Porto Dragons", "Braga Warriors",
                "Amsterdam Canals", "Eindhoven Sparks", "Rotterdam Fleet", "Bruges Knights",
                "Istanbul Falcons", "Istanbul Lions", "Baku Flames", "Prague Astrals",
                "Athens Titans", "Copenhagen Frost", "Oslo Aurora", "Almaty Peaks"
            };

            var result = new List<TeamData>(36);
            for (int i = 0; i < names.Length; i++)
            {
                uint hash = StableHash(names[i]);
                float hue = (hash % 1000) / 1000f;
                Color primary = Color.HSVToRGB(hue, 0.78f, 0.92f);
                Color secondary = Color.HSVToRGB((hue + 0.5f) % 1f, 0.42f, 1f);
                result.Add(new TeamData($"CLUB-{i:00}", names[i], "Champions Circuit",
                    73 + (int)(hash % 18), primary, secondary, true));
            }
            return result;
        }

        private static uint StableHash(string value)
        {
            unchecked
            {
                uint hash = 2166136261;
                foreach (char c in value)
                {
                    hash ^= c;
                    hash *= 16777619;
                }
                return hash;
            }
        }
    }
}
