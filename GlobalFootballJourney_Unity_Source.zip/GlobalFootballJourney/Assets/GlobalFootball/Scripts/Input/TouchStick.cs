using UnityEngine;
using UnityEngine.EventSystems;

namespace GlobalFootball
{
    public sealed class TouchStick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        public RectTransform Knob { get; set; }
        public float Radius { get; set; } = 72f;

        private RectTransform rect;

        private void Awake() => rect = transform as RectTransform;

        public void OnPointerDown(PointerEventData eventData) => UpdateValue(eventData);
        public void OnDrag(PointerEventData eventData) => UpdateValue(eventData);

        public void OnPointerUp(PointerEventData eventData)
        {
            if (Knob != null)
                Knob.anchoredPosition = Vector2.zero;
            UnifiedInput.SetTouchMove(Vector2.zero);
        }

        private void UpdateValue(PointerEventData eventData)
        {
            if (rect == null || Knob == null)
                return;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(rect, eventData.position,
                eventData.pressEventCamera, out Vector2 local);
            Vector2 normalized = Vector2.ClampMagnitude(local / Radius, 1f);
            Knob.anchoredPosition = normalized * Radius;
            UnifiedInput.SetTouchMove(normalized);
        }
    }
}
