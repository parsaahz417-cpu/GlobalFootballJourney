using UnityEngine;
using UnityEngine.InputSystem;

namespace GlobalFootball
{
    public enum TouchAction
    {
        Pass,
        Shoot,
        Switch,
        Sprint,
        Pause
    }

    public static class UnifiedInput
    {
        private static Vector2 touchMove;
        private static bool touchSprint;
        private static bool passQueued;
        private static bool shootQueued;
        private static bool switchQueued;
        private static bool pauseQueued;

        public static Vector2 Move
        {
            get
            {
                if (touchMove.sqrMagnitude > 0.01f)
                    return Vector2.ClampMagnitude(touchMove, 1f);

                Vector2 value = Vector2.zero;
                Keyboard keyboard = Keyboard.current;
                if (keyboard != null)
                {
                    if (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed) value.x -= 1f;
                    if (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed) value.x += 1f;
                    if (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed) value.y -= 1f;
                    if (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed) value.y += 1f;
                }

                Gamepad gamepad = Gamepad.current;
                if (gamepad != null && gamepad.leftStick.ReadValue().sqrMagnitude > value.sqrMagnitude)
                    value = gamepad.leftStick.ReadValue();
                return Vector2.ClampMagnitude(value, 1f);
            }
        }

        public static bool SprintHeld
        {
            get
            {
                Keyboard keyboard = Keyboard.current;
                Gamepad gamepad = Gamepad.current;
                return touchSprint ||
                       (keyboard != null && (keyboard.leftShiftKey.isPressed || keyboard.rightShiftKey.isPressed)) ||
                       (gamepad != null && gamepad.rightShoulder.isPressed);
            }
        }

        public static bool ConsumePass()
        {
            bool pressed = passQueued;
            passQueued = false;
            Keyboard keyboard = Keyboard.current;
            Gamepad gamepad = Gamepad.current;
            return pressed || (keyboard != null && (keyboard.jKey.wasPressedThisFrame || keyboard.spaceKey.wasPressedThisFrame)) ||
                   (gamepad != null && gamepad.buttonSouth.wasPressedThisFrame);
        }

        public static bool ConsumeShoot()
        {
            bool pressed = shootQueued;
            shootQueued = false;
            Keyboard keyboard = Keyboard.current;
            Gamepad gamepad = Gamepad.current;
            return pressed || (keyboard != null && keyboard.kKey.wasPressedThisFrame) ||
                   (gamepad != null && gamepad.buttonWest.wasPressedThisFrame);
        }

        public static bool ConsumeSwitch()
        {
            bool pressed = switchQueued;
            switchQueued = false;
            Keyboard keyboard = Keyboard.current;
            Gamepad gamepad = Gamepad.current;
            return pressed || (keyboard != null && (keyboard.lKey.wasPressedThisFrame || keyboard.qKey.wasPressedThisFrame)) ||
                   (gamepad != null && gamepad.leftShoulder.wasPressedThisFrame);
        }

        public static bool ConsumePause()
        {
            bool pressed = pauseQueued;
            pauseQueued = false;
            Keyboard keyboard = Keyboard.current;
            Gamepad gamepad = Gamepad.current;
            return pressed || (keyboard != null && keyboard.escapeKey.wasPressedThisFrame) ||
                   (gamepad != null && gamepad.startButton.wasPressedThisFrame);
        }

        public static void SetTouchMove(Vector2 value) => touchMove = value;

        public static void SetTouchAction(TouchAction action, bool isDown)
        {
            switch (action)
            {
                case TouchAction.Pass when isDown: passQueued = true; break;
                case TouchAction.Shoot when isDown: shootQueued = true; break;
                case TouchAction.Switch when isDown: switchQueued = true; break;
                case TouchAction.Pause when isDown: pauseQueued = true; break;
                case TouchAction.Sprint: touchSprint = isDown; break;
            }
        }

        public static void ResetTouch()
        {
            touchMove = Vector2.zero;
            touchSprint = false;
            passQueued = false;
            shootQueued = false;
            switchQueued = false;
            pauseQueued = false;
        }
    }
}
