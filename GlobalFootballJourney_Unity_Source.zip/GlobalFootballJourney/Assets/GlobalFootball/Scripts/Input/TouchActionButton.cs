using UnityEngine;
using UnityEngine.EventSystems;

namespace GlobalFootball
{
    public sealed class TouchActionButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler,
        IPointerExitHandler
    {
        public TouchAction Action { get; set; }

        public void OnPointerDown(PointerEventData eventData)
        {
            UnifiedInput.SetTouchAction(Action, true);
            transform.localScale = Vector3.one * 0.92f;
        }

        public void OnPointerUp(PointerEventData eventData) => Release();
        public void OnPointerExit(PointerEventData eventData) => Release();

        private void Release()
        {
            UnifiedInput.SetTouchAction(Action, false);
            transform.localScale = Vector3.one;
        }
    }
}
