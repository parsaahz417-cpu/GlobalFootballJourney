#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;
using UnityEngine.SceneManagement;

namespace GlobalFootball.EditorTools
{
    [InitializeOnLoad]
    public static class ProjectAutoSetup
    {
        private const string ScenePath = "Assets/Scenes/Boot.unity";
        private const string PipelinePath = "Assets/GlobalFootball/Settings/GlobalFootballURP.asset";
        private const string DefaultRendererPath =
            "Packages/com.unity.render-pipelines.universal/Runtime/Data/UniversalRendererData.asset";
        private const string SessionKey = "GlobalFootball.AutoSetupComplete";

        static ProjectAutoSetup()
        {
            EditorApplication.delayCall += EnsureProjectReady;
        }

        [MenuItem("Global Football/Setup/Repair Project Setup")]
        public static void EnsureProjectReady()
        {
            if (SessionState.GetBool(SessionKey, false) && File.Exists(ScenePath) &&
                AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath) != null)
                return;

            Directory.CreateDirectory("Assets/Scenes");
            if (!File.Exists(ScenePath))
            {
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                EditorSceneManager.SaveScene(scene, ScenePath);
            }

            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EnsureRenderPipeline();
            EnsureInputSystem();
            PlayerSettings.companyName = "Independent Prototype";
            PlayerSettings.productName = "Global Football Journey";
            PlayerSettings.bundleVersion = "0.1.0";
            PlayerSettings.defaultScreenWidth = 1920;
            PlayerSettings.defaultScreenHeight = 1080;
            PlayerSettings.fullScreenMode = FullScreenMode.FullScreenWindow;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.colorSpace = ColorSpace.Linear;
            QualitySettings.vSyncCount = 0;
            AssetDatabase.SaveAssets();
            SessionState.SetBool(SessionKey, true);
            Debug.Log("Global Football Journey setup is ready. Open Assets/Scenes/Boot.unity and press Play.");
        }

        [MenuItem("Global Football/Validate/Check Team Catalog")]
        public static void ValidateTeams()
        {
            int national = TeamCatalog.NationalTeams.Count;
            int clubs = TeamCatalog.ClubTeams.Count;
            if (national == 211 && clubs == 36)
                Debug.Log("Team catalog valid: 211 national teams and 36 original clubs.");
            else
                Debug.LogError($"Team catalog mismatch: {national} national teams and {clubs} clubs.");
        }

        private static void EnsureRenderPipeline()
        {
            UniversalRenderPipelineAsset pipeline =
                AssetDatabase.LoadAssetAtPath<UniversalRenderPipelineAsset>(PipelinePath);
            if (pipeline == null)
            {
                ScriptableRendererData renderer =
                    AssetDatabase.LoadAssetAtPath<ScriptableRendererData>(DefaultRendererPath);
                if (renderer == null)
                {
                    Debug.LogWarning("URP default renderer was not found. Package resolution may still be running.");
                    return;
                }

                Directory.CreateDirectory("Assets/GlobalFootball/Settings");
                pipeline = UniversalRenderPipelineAsset.Create(renderer);
                pipeline.name = "Global Football URP";
                pipeline.renderScale = 1f;
                pipeline.shadowDistance = 70f;
                pipeline.msaaSampleCount = 2;
                AssetDatabase.CreateAsset(pipeline, PipelinePath);
            }

            GraphicsSettings.defaultRenderPipeline = pipeline;
            QualitySettings.renderPipeline = null;
        }

        private static void EnsureInputSystem()
        {
            Object[] settingsAssets = AssetDatabase.LoadAllAssetsAtPath("ProjectSettings/ProjectSettings.asset");
            if (settingsAssets == null || settingsAssets.Length == 0)
                return;

            var serializedSettings = new SerializedObject(settingsAssets[0]);
            SerializedProperty activeInputHandler = serializedSettings.FindProperty("activeInputHandler");
            if (activeInputHandler == null || activeInputHandler.intValue == 1)
                return;

            activeInputHandler.intValue = 1;
            serializedSettings.ApplyModifiedPropertiesWithoutUndo();
            Debug.Log("Active Input Handling set to the new Input System.");
        }
    }
}
#endif
