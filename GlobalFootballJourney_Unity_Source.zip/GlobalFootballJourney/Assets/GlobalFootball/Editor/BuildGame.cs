#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace GlobalFootball.EditorTools
{
    public static class BuildGame
    {
        private static readonly string[] Scenes = { "Assets/Scenes/Boot.unity" };

        [MenuItem("Global Football/Build/Android APK")]
        public static void BuildAndroidApk()
        {
            ProjectAutoSetup.EnsureProjectReady();
            Directory.CreateDirectory("Builds/Android");
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.indie.globalfootballjourney");
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel26;
            EditorUserBuildSettings.buildAppBundle = false;
            RunBuild(BuildTarget.Android, "Builds/Android/GlobalFootballJourney.apk");
        }

        [MenuItem("Global Football/Build/Windows 64-bit")]
        public static void BuildWindows()
        {
            ProjectAutoSetup.EnsureProjectReady();
            Directory.CreateDirectory("Builds/Windows");
            RunBuild(BuildTarget.StandaloneWindows64, "Builds/Windows/GlobalFootballJourney.exe");
        }

        [MenuItem("Global Football/Build/Linux 64-bit")]
        public static void BuildLinux()
        {
            ProjectAutoSetup.EnsureProjectReady();
            Directory.CreateDirectory("Builds/Linux");
            RunBuild(BuildTarget.StandaloneLinux64, "Builds/Linux/GlobalFootballJourney.x86_64");
        }

        private static void RunBuild(BuildTarget target, string output)
        {
            if (!ProjectValidation.ValidateForBuild())
                throw new BuildFailedException("Global Football validation failed. Fix Console errors before building.");

            BuildPlayerOptions options = new BuildPlayerOptions
            {
                scenes = Scenes,
                target = target,
                locationPathName = output,
                options = BuildOptions.CleanBuildCache
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            BuildSummary summary = report.summary;
            if (summary.result == BuildResult.Succeeded)
                Debug.Log($"Build succeeded: {output} ({summary.totalSize / 1048576f:0.0} MB)");
            else
                Debug.LogError($"Build failed for {target}. Install the matching Unity Hub platform module and inspect the Console.");
        }
    }
}
#endif
