#if UNITY_EDITOR
using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;
using UnityEngine.Rendering;

namespace GlobalFootball.EditorTools
{
    public static class ProjectValidation
    {
        [MenuItem("Global Football/Validate/Run All Checks")]
        public static void RunAllChecks()
        {
            bool valid = ValidateForBuild();
            if (valid)
                Debug.Log("Global Football validation passed: catalogs, IDs, stage counts, scene and URP are ready.");
        }

        public static bool ValidateForBuild()
        {
            bool valid = true;
            IReadOnlyList<TeamData> nations = TeamCatalog.NationalTeams;
            IReadOnlyList<TeamData> clubs = TeamCatalog.ClubTeams;
            if (nations.Count != 211 || clubs.Count != 36)
            {
                Debug.LogError($"Expected 211 national teams and 36 clubs; found {nations.Count} and {clubs.Count}.");
                valid = false;
            }

            List<TeamData> allTeams = nations.Concat(clubs).ToList();
            if (allTeams.Select(x => x.Id).Distinct().Count() != allTeams.Count)
            {
                Debug.LogError("Duplicate team IDs detected.");
                valid = false;
            }

            if (allTeams.Any(x => string.IsNullOrWhiteSpace(x.DisplayName) || x.Rating < 1))
            {
                Debug.LogError("A team has invalid display data.");
                valid = false;
            }

            var expectedStages = new Dictionary<CompetitionType, int>
            {
                [CompetitionType.QuickMatch] = 1,
                [CompetitionType.InternationalCup] = 8,
                [CompetitionType.ChampionsCup] = 13,
                [CompetitionType.Journey] = 16
            };
            foreach (KeyValuePair<CompetitionType, int> item in expectedStages)
            {
                var session = new CompetitionSession { Type = item.Key };
                if (session.TotalStages != item.Value)
                {
                    Debug.LogError($"{item.Key} expected {item.Value} stages but reports {session.TotalStages}.");
                    valid = false;
                }
            }

            if (!File.Exists("Assets/Scenes/Boot.unity"))
            {
                Debug.LogError("Boot scene is missing. Run Global Football > Setup > Repair Project Setup.");
                valid = false;
            }

            if (GraphicsSettings.defaultRenderPipeline == null)
            {
                Debug.LogError("URP is not assigned. Run Global Football > Setup > Repair Project Setup.");
                valid = false;
            }

            return valid;
        }
    }
}
#endif
